var config = {
  generatedByVersion: '0.12.12'
};

module.exports = config;
