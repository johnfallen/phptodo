var router = new geddy.RegExpRouter();

router.get('/').to('Main.index');
router.match('/login').to('Main.login');
router.match('/dologin').to('Main.dologin');
router.match('/logout').to('Main.logout');

router.match('/songs').to('Songs.index');
router.match('/songs/show').to('Songs.show');
router.match('/songs/edit').to('Songs.edit');
router.match('/songs/edit/').to('Songs.edit');
router.match('/songs/delete').to('Songs.delete');
router.match('/songs/delete/').to('Songs.delete');
router.match('/songs/save').to('Songs.save');
router.match('/songs/save/').to('Songs.save');

router.match('/news').to('News.index');
router.match('/news/').to('News.index');
router.match('/news/breaking').to('News.breaking');
router.match('/news/breaking/').to('News.breaking');
router.match('/news/breakingsave').to('News.breakingsave');
router.match('/news/breakingsave/').to('News.breakingsave');

router.match('/question').to('Questions.index');
router.match('/question/').to('Questions.index');
router.match('/question/add').to('Questions.add');
router.match('/question/delete/').to('Questions.delete');
router.match('/question/edit').to('Questions.edit');
router.match('/question/edit/').to('Questions.edit');
router.match('/question/save').to('Questions.save');
router.match('/question/save/').to('Questions.save');

router.match('/promo').to('Promos.index');
router.match('/promo/').to('Promos.index');
router.match('/promo/save').to('Promos.save');
router.match('/promo/save/').to('Promos.save');

router.match('/admin').to('Admins.index');
router.match('/admin/').to('Admins.index');
router.match('/admin/add').to('Admins.add');
router.match('/admin/delete/').to('Admins.delete');
router.match('/admin/edit').to('Admins.edit');
router.match('/admin/edit/').to('Admins.edit');
router.match('/admin/save').to('Admins.save');
router.match('/admin/save/').to('Admins.save');

exports.router = router;
