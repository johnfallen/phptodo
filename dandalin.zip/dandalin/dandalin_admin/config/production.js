var config = {
  appName: 'Dandalin VOA Administration'
, detailedErrors: false
, hostname: null
, port: 8443
, model: {
    defaultAdapter: 'mongo'
  }
, db: {
    mongo: {
      username: null
    , dbname: 'dandalin-production'
    , prefix: null
    , password: null
    , host: 'localhost'
    , port: 27017
    }
  },
    sessions: {
        store: 'filesystem'
        , filename: '_session_store.json'
        , key: 'sid'
        , expiry: 14 * 24 * 60 * 60
    }

    , ssl: {
        key: '/etc/apache2/SSL/soccer-epl.voanews.com.key'
        , cert: '/etc/apache2/SSL/soccer-epl.voanews.com.crt'
        , ca : '/etc/apache2/SSL/gd_bundle-g2-g1.crt'
    }
};

module.exports = config;

