/**
 * @fileOverview 	I am the songs controller.
 * @author 			John Allen <jallen@bbg.gov>
 * @version 		0.0.1
 * @module 			Questions
 */
'use strict';

/* *************************** Required Classes **************************** */
var moment = require('moment');
var mongoose = require('mongoose');
var questionModel = require('../../../packages/dandalin/server/models/question_of_the_day');

/* *************************** Constructor Code **************************** */
var question = mongoose.model('Question');


var Questions = function () {
  this.respondsWith = ['html', 'json', 'xml', 'js', 'txt'];


  /**
   * I run before ALL actions of this controller. I check if a user is logged
   * in, and if not I redirect them to the login screen.
   */
  this.before(function(){
    if(this.session.get('isLoggedIn') !== true){
      this.redirect('/login');
    }
  });

  /**
   * I return all of the Questions to the default view.
   * @param req
   * @param resp
   * @param params
   */
  this.index = function (req, resp, params) {

    var self = this;

    if(self.session.get('questionList') === undefined ){

      question.find(function (err, questions) {

        var local = self;

        if(err){
          console.log( err );
        }

        local.session.set('questionList', questions);
        local.redirect('/question');
      });
    } else {

      var myNewThing = self.session.get('questionList');

      var newObject = JSON.parse(JSON.stringify( myNewThing ));

      self.session.unset('questionList');

      if (this.session.get('updateMessage') !== undefined){
        this.flash.success( this.session.get('updateMessage') );
        this.session.unset('updateMessage');
      }

      this.respond({params: params, questionList: newObject});

    }
  };


  /**
   * I add a question then show the edit form.
   * @param req
   * @param resp
   * @param params
   */
  this.add = function (req, resp, params) {

    var newQuestion = new question({question : 'ENTER TEXT'});

    // add the default TWO call outs. THERE WILL ONLY BE 2 CALL OUTS! :)
    var defaultFaceBookCallOut = newQuestion.getFaceBookCallOut();
    var defaultEmptyCallOut = newQuestion.getEmptyCallOut();

    newQuestion.callOut = [defaultFaceBookCallOut, defaultEmptyCallOut];

    newQuestion.save(function(error){
      if (error){
        console.log(error);
      }

    });

    this.respond(
        {
          params: params,
          question : newQuestion,
          moment: moment
        },
        {template: '/questions/edit'}
    );
  };


  /**
   * I deleat a quesiton and redirect to the index view.
   * @param req
   * @param resp
   * @param params
   */
  this.delete = function (req, resp, params) {

    var self = this;
    var selfParams = params;

    question.remove( {_id : params._id.toString()}, function (err) {

      var local = self;
      var localParams = selfParams;

      if(err){
        console.log( err );
      }

      local.session.set('updateMessage', 'Question Was Deleted!');
      local.redirect({controller: 'question'});

    });
  };


  /**
   * I get a question and display it in the edit form.
   * @param req
   * @param resp
   * @param params
   */
  this.edit = function (req, resp, params) {
    var self = this;
    var selfParams = params;

    // if we don't have a song in the session get it from the db
    if(self.session.get('question') === undefined) {

      var local = self;
      var localParams = selfParams;

      // find the song and add it to the session object
      question.findById(params._id.toString(), function (err, question) {

        if(err){
          console.log( err );
        }

        //console.log(question);

        local.session.set('question', question);
        local.redirect('/question/edit/?_id=' + params._id.toString());
      });

    } else {

      // copy the object so we can clear it form the session object.
      var myNewThing = self.session.get('question');
      var newObject = JSON.parse(JSON.stringify( myNewThing ));

      self.session.unset('question');

      this.respond({params: params, question: newObject, moment : moment});
    }
  };


  /**
   * I save a question and redirect to the index view.
   * @param req
   * @param resp
   * @param params
   */
  this.save = function (req, resp, params) {

    var self = this;
    var selfParams = params;

    question.findById( params._id.toString(), function (err, theQuestion) {

      if(err){
        console.log( err );
      }

      var localParams = selfParams;

      localParams.start = moment(localParams.start)._d;
      localParams.end = moment(localParams.start)._d;

      // get these values from the form
      var callOutOne = {
        link : localParams.callOutOneLink,
        text : localParams.callOutOneText
      };

      // eventually get these from the form when we launch the functionality
      var callOutTwo = theQuestion.getEmptyCallOut();

      localParams.callOut = [callOutOne, callOutTwo];

      theQuestion.update(localParams).exec();
    });

    this.session.set('updateMessage', 'Question Was Updated!');
    this.redirect({controller: 'question'});
  };
};
exports.Questions = Questions;
