/**
 * @fileOverview 	I am the main controller.
 * @author 			John Allen <jallen@bbg.gov>
 * @version 		0.0.1
 * @module 			Main
 */
'use strict';

/* *************************** Required Classes **************************** */
var fs = require('fs');
var AdminService = require('../service/admin/AdminService');
var loginTemplate = 'app/views/main/login';

var Main = function () {

  /**
   * I display the homepage of the application.
   * @param req
   * @param resp
   * @param params
   */
  this.index = function (req, resp, params) {
    this.respond({params: params}, {
      format: 'html'
      , template: loginTemplate
    });
  };


  /**
   * I display the login screen
   * @param req
   * @param resp
   * @param params
   */
  this.login = function (req, resp, params) {

    this.session.set('isLoggedIn', false);

    this.respond(
        {params: params},
        {
          format: 'html',
          template: loginTemplate
        }
    );
  };


  /**
   * I attempt to log a user into the application.
   * @param req
   * @param resp
   * @param params
   */
  this.dologin = function (req, resp, params) {

    var requestArguments = {
      'req' : req,
      'resp' : resp,
      'params' : params,
      'that' : this
    };

    AdminService.doLogin(
        params.username,
        params.password,
        this.afterLogin,
        requestArguments
    );
  };


  /**
   * I am called by the AdminService after authentication check
   * @param req
   * @param resp
   * @param params
   * @param isAuthenticated
   * @param that
   */
  this.afterLogin = function (req, resp, params, isAuthenticated, that) {

    if( isAuthenticated ){

      // display the menu SET IN TH
      global.DISPLAY_MENU = true;

      that.session.set('isLoggedIn', true);
      that.redirect('/songs');

    } else {

      that.flash.error('Login credentials are invalid');
      that.redirect('/login');
    }
  };



  /**
   * I log a user OUT of the system and redirect to the login form.
   * @param req
   * @param resp
   * @param params
   */
  this.logout = function (req, resp, params) {

    global.DISPLAY_MENU = false;

    this.session.set('isLoggedIn', false);
    this.redirect('/login');
  };
};
exports.Main = Main;
