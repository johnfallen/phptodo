/**
 * @fileOverview 	I am the admin controller.
 * @author 			John Allen <jallen@bbg.gov>
 * @version 		0.0.1
 * @module 			Admins
 */
'use strict';

/* *************************** Required Classes **************************** */
var mongoose = require('mongoose');
var AdminService = require('../service/admin/AdminService');
var adminModel = require('../service/admin/admin_model/Admin');

/* *************************** Constructor Code **************************** */
var admin = mongoose.model('Admin');

var Admins = function () {
  this.respondsWith = ['html', 'json', 'xml', 'js', 'txt'];

  /**
   * I run before ALL actions of this controller. I check if a user is logged
   * in, and if not I redirect them to the login screen.
   */
  this.before(function(){
    if(this.session.get('isLoggedIn') !== true){
      this.redirect('/login');
    }
  });


  /**
   * I display a list of admins
   * @param req
   * @param resp
   * @param params
   */
  this.index = function (req, resp, params) {

    var self = this;

    // I super duper dislike how im doing this....
    if(self.session.get( 'adminList' ) === undefined ) {

      admin.find({}).exec(function( err, list ) {

        var local = self;

        if(err){
          console.log( err );
        }

        local.session.set('adminList', list);
        local.redirect('/admin');

      });

    } else {

      var myNewThing = self.session.get('adminList');

      var newObject = JSON.parse( JSON.stringify( myNewThing ) );

      self.session.unset( 'adminList' );

      if ( this.session.get( 'updateMessage' ) !== undefined ){
        this.flash.success( this.session.get('updateMessage') );
        this.session.unset('updateMessage' );
      }

      this.respond({params: params, adminList: newObject});
    }
  };


  /**
   * I create an admin and display the edit form
   * @param req
   * @param resp
   * @param params
   */
  this.add = function (req, resp, params) {

    var newAdmin = new admin({username : 'ENTER USERNAME', password : 'password'});

    newAdmin.save(function(error){
      if (error){
        console.log(error);
      }
    });

    this.respond(
        {
          params: params,
          admin : newAdmin
        },
        {template: '/admins/edit'}
    );
  };


  /**
   * I delete an admin
   * @param req
   * @param resp
   * @param params
   */
  this.delete = function (req, resp, params) {
    var self = this;

    admin.remove( {_id : params._id.toString()}, function (err) {

      var local = self;

      if( err ){
        console.log( err );
      }

      local.session.set('updateMessage', 'Admin Was Deleted!');
      local.redirect({controller: 'admin'});
    });
  };


  /**
   * I get a user and show it in the edit form.
   * @param req
   * @param resp
   * @param params
   */
  this.edit = function (req, resp, params) {
    var self = this;
    var selfParams = params;

    // if we don't have a song in the session get it from the db
    if(self.session.get('admin') === undefined) {

      var local = self;
      var localParams = selfParams;

      // find the song and add it to the session object
      admin.findById(params._id.toString(), function (err, admin) {

        if(err){
          console.log( err );
        }

        local.session.set('admin', admin);
        local.redirect('/admin/edit/?_id=' + params._id.toString());
      });

    } else {

      // copy the object so we can clear it form the session object.
      var myNewThing = self.session.get('admin');
      var newObject = JSON.parse(JSON.stringify( myNewThing ));

      self.session.unset('admin');

      this.respond({params: params, admin: newObject});
    }
  };


  /**
   * I save an admin user and then redirect to the admin index action
   * @param req
   * @param resp
   * @param params
   */
  this.save = function (req, resp, params) {
    var self = this;
    var selfParams = params;

    admin.findById( params._id.toString(), function (err, fetchedAdmin) {

      if (err) {
        console.log(err);
      }

      var localParams = selfParams;

      // only update passwords if they are any.
      if (localParams.password.length) {

        var newPassword = AdminService.createPassword(localParams.password);

        fetchedAdmin.update(
            {
              username: localParams.username,
              password: newPassword
            }
        ).exec();

      } else { // just update the username

        fetchedAdmin.update(
            {
              username: localParams.username
            }
        ).exec();
      }
    });

    this.session.set('updateMessage', 'Admin Was Updated!');
    this.redirect({controller: 'admin'});
  };

  this.remove = function (req, resp, params) {
    this.respond({params: params});
  };

};

exports.Admins = Admins;
