/**
 * @fileOverview 	I am the songs controller.
 * @author 			John Allen <jallen@bbg.gov>
 * @version 		0.0.1
 * @module 			Songs
 */
'use strict';

/* *************************** Required Classes **************************** */
var mongoose = require('mongoose');
var songModel = require('../../../packages/dandalin/server/models/song');

/* *************************** Constructor Code **************************** */
var song = mongoose.model('Song');


// controller
var Songs = function () {
  this.respondsWith = ['html', 'json', 'xml', 'js', 'txt'];


  /**
   * I run before ALL actions of this controller. I check if a user is logged
   * in, and if not I redirect them to the login screen.
   */
  this.before(function(){
    if(this.session.get('isLoggedIn') !== true){
      this.redirect('/login');
    }
  });


  /**
   * I show the default view for song administration. I show a list of all the
   * Song objects
   * @param req
   * @param resp
   * @param params
   */
  this.index = function (req, resp, params) {
    var self = this;

    // I super duper dislike how im doing this....
    if(self.session.get( 'songList' ) === undefined ) {

      song.find({}).sort({artist: 'asc', title: 'asc'}).exec(function( err, list ) {

        var local = self;

        if(err){
          console.log( err );
        }

        local.session.set('songList', list);
        local.redirect('/songs');

      });

    } else {

      var myNewThing = self.session.get('songList');

      var newObject = JSON.parse( JSON.stringify( myNewThing ) );

      self.session.unset( 'songList' );

      if ( this.session.get( 'updateMessage' ) !== undefined ){
        this.flash.success( this.session.get('updateMessage') );
        this.session.unset('updateMessage' );
      }

      this.respond({params: params, songList: newObject});
    }
  };


  /**
   * I delete an On Demand song
   * @param req
   * @param resp
   * @param params
   */
  this.delete = function ( req, resp, params ) {

    song.remove( { _id: params._id.toString() }, function(err){
      if(err){
        console.log(err);
      }
    });

    // Save the resource, then display the item page
    this.session.set('updateMessage', 'Song Was Deleted!');
    this.redirect('/songs/');
  };


  /**
   * I show the edit form for a Song object
   * @param req
   * @param resp
   * @param params
   */
  this.edit = function (req, resp, params) {

    var self = this;
    var selfParams = params;

    // if we don't have a song in the session get it from the db
    if(self.session.get('song') === undefined) {

      var local = self;
      var localParams = selfParams;

      // find the song and add it to the session object
      song.findById(params._id.toString(), function (err, song) {

        if(err){
          console.log( err );
        }

        local.session.set('song', song);
        local.redirect('/songs/edit/?_id=' + params._id.toString());

      });

    } else {

      // copy the object so we can clear it form the session object.
      var myNewThing = self.session.get('song');
      var newObject = JSON.parse(JSON.stringify( myNewThing ));

      self.session.unset('song');

      this.respond({params: params, song: newObject});
    }
  };


  /**
   * I save a song object and re-direct to the edit screen again.
   * @param req
   * @param resp
   * @param params
   */
  this.save = function (req, resp, params) {
    var self = this;
    var selfParams = params;

    song.findById( params._id.toString(), function (err, fetchedSong) {

      if(err){
        console.log( err );
      }

      var localParams = selfParams;

      fetchedSong.update(localParams).exec();

    });

    // Save the resource, then display the item page
    this.session.set('updateMessage', 'Song Was Updated! ARTIST: ' + params.title + ' SONG: ' + params.artist);
    this.redirect({controller: 'songs'});
  };



  this.add = function (req, resp, params) {
    this.respond({params: params});
  };

  this.create = function (req, resp, params) {
    // Save the resource, then display index page
    this.redirect({controller: this.name});
  };

  this.show = function (req, resp, params) {

    this.respond({params: params});
  };

  this.update = function (req, resp, params) {
    // Save the resource, then display the item page
    this.redirect({controller: this.name, id: params.id});
  };
};

exports.Songs = Songs;
