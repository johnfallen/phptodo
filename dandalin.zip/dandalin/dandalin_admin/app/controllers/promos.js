/**
 * @fileOverview 	I am the Promos controller.
 * @author 			John Allen <jallen@bbg.gov>
 * @version 	    1.0.0
 * @module 			Promos
 */
'use strict';
/* *************************** Required Classes **************************** */
var fs = require('fs');
// get the MEAN config data.
var mainAppConfig = require('../../../config/env/all');
var utils = require('../../../packages/dandalin/server/lib/Utils');

/* *************************** Constructor Code **************************** */
var promoJSONFilePath = mainAppConfig.jsonDataDirectory + '/promo.json';



var Promos = function () {
  this.respondsWith = ['html', 'json', 'xml', 'js', 'txt'];


  /**
   * I run before ALL actions of this controller. I check if a user is logged
   * in, and if not I redirect them to the login screen.
   */
  this.before(function(req, resp, params){

    if(this.session.get('isLoggedIn') !== true){
      this.redirect('/login');
    }

  });

  /**
   * I am the default view for Promos
   * @param req
   * @param resp
   * @param params
   */
  this.index = function (req, resp, params) {

    var json = utils.readJSONFile(promoJSONFilePath);

    this.respond({params: params, promo : json});
  };


  /**
   * I save the Promos and redirect to the index page.
   * @param req
   * @param resp
   * @param params
   */
  this.save = function (req, resp, params) {

    //console.log('**********************');
    //console.log(params);

    var jsonToSave = [
      {
        isFullWidth : params.top_isFullWidth,
        items :
          [
            {
              link : params.top_link_0,
              image : params.top_image_0,
              text : params.top_text_0
            },
            {
              link : params.top_link_1,
              image : params.top_image_1,
              text : params.top_text_1
            },
          ]
      },
      {
        isFullWidth : params.bottom_isFullWidth,
        items :
          [
            {
              link : params.bottom_link_0,
              image : params.bottom_image_0,
              text : params.bottom_text_0
            },
            {
              link : params.bottom_link_1,
              image : params.bottom_image_1,
              text : params.bottom_text_1
            },
          ]
      }
    ];


    utils.writeJSONFile(promoJSONFilePath, jsonToSave);

    this.flash.success('The Promotions Were Saved.');
    this.redirect('/promo/');
  };
};
exports.Promos = Promos;
