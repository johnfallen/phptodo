/**
 * @fileOverview 	I am the news controller. I control breaking new output.
 * @author 			John Allen <jallen@bbg.gov>
 * @version 		0.0.1
 * @module 			News
 */
'use strict';
/* *************************** Required Classes **************************** */
var fs = require('fs');
var faye = require('faye');
// get the MEAN.io config file
var mainAppConfig = require('../../../config/env/all.js');
var utils = require('../../../packages/dandalin/server/lib/Utils');


/* *************************** Constructor Code **************************** */
var breakingNewsJSONFilePath = mainAppConfig.jsonDataDirectory + '/news_breaking.json';

// set up the faye client
var fayeClient = new faye.Client(mainAppConfig.faye.url);
fayeClient.addExtension({
  outgoing: function( message, callback ) {

    message.ext = message.ext || {};
    message.ext.password = mainAppConfig.faye.publishPassword;

    callback( message );
  }
});


var News = function () {
  this.respondsWith = ['html', 'json', 'xml', 'js', 'txt'];

  /**
   * I run before ALL actions of this controller. I check if a user is logged
   * in, and if not I redirect them to the login screen.
   */
  this.before(function(req, resp, params){

    if(this.session.get('isLoggedIn') !== true){
      this.redirect('/login');
    }

  });



  /**
   * I am the index page for the news section.
   * @param req
   * @param resp
   * @param params
   */
  this.index = function (req, resp, params) {
    this.respond({params: params});
  };


  /**
   * I display the breaking news management form.
   * @param req
   * @param resp
   * @param params
   */
  this.breaking = function (req, resp, params) {

    var self = this;

    var news = utils.readJSONFile(breakingNewsJSONFilePath);

    this.respond({params: params, news: news});
  };


  /**
   * I save the text of the breaking news content and also broadcast it to faye.
   * @param req
   * @param resp
   * @param params
   */
  this.breakingsave = function (req, resp, params) {

    var news = {
      text : params.text,
      url : params.url
    };

    utils.writeJSONFile(breakingNewsJSONFilePath, news);

    var dataToSendDownTheWire = JSON.stringify( news );

    fayeClient.publish( '/' + mainAppConfig.faye.breakingNewsChannel, { text:dataToSendDownTheWire } );

    this.flash.success('The News Was Saved.');
    this.redirect('/news/breaking');
  };

};

exports.News = News;
