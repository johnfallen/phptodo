/**
 * @fileOverview 	I am the Dandalin Application controller.
 * @author 			John Allen <jallen@bbg.gov>
 * @version 		0.0.1
 * @module 			Application
 */
'use strict';

/* *************************** Required Classes **************************** */

// MAKE THE CONNECTION TO MONGODB Here and only here.
var mongoose = require('mongoose');

var dbConnectionString = 'mongodb://localhost:27017/' + geddy.config.db.mongo.dbname;

mongoose.connect(dbConnectionString);

// GROSS!!!! but only referenced in the main.js controller... :P
global.DISPLAY_MENU = false;

var Application = function () {
};
exports.Application = Application;
