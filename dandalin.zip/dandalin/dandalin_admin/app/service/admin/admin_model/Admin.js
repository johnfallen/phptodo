/**
 * @fileOverview 	I model an admin user.
 * @author 			John Allen <jallen@bbg.gov>
 * @version 		0.0.1
 * @module 			Users.js
 */
'use strict';

/* *************************** Constructor Code **************************** */
var mongoose = require('mongoose');
var Schema = mongoose.Schema;


/**
 * Admin Schema
 */
var AdminSchema = new Schema({
	active: {
		type: Number,
		required: true,
		default: 1
	},
	username: {
		type: String,
		required: true,
		trim: true
	},
	password: {
		type: String,
		required: true,
		trim: true
	}
}, { collection: 'admin' });


/* Statics */
AdminSchema.statics.load = function( id, cb ) {
	this.findOne({
		_id: id
	}).exec(cb);
};

mongoose.model('Admin', AdminSchema);
