/**
 * @fileOverview 	I am the API to interact with Users.
 * @author 			John Allen <jallen@bbg.gov>
 * @version 		1.0.0
 * @module 			UserService
 */
'use strict';
/*jslint unused:false*/

/* *************************** Required Classes **************************** */
var mongoose = require('mongoose');
var bcrypt = require('bcrypt');
var config = require('../../../config/environment');
var adminModel = require('./admin_model/Admin');
var admin = mongoose.model('Admin');


/* *************************** Constructor Code **************************** */
// create a default user if its not there...
createDefaultAdminUser();

/* *************************** Public Methods ****************************** */
/**
 * I authenticate a user.
 * @param userName
 * @param password
 * @param callback
 * @param callbackArgs
 * @returns {boolean}
 */
function doLogin ( userName, password, callback, callbackArgs ) {

	admin.findOne({'username' : userName}, function(err, theAdmin){

		var isAuthenticated = false;

		// if there is an admin found check the password.
		if( theAdmin != null ){
			isAuthenticated = checkPassword(password, theAdmin.password);
		}

		callback(
			callbackArgs.req,
			callbackArgs.resp,
			callbackArgs.params,
			isAuthenticated,
			callbackArgs.that
		)
	});

}
exports.doLogin = doLogin;


/**
 * I salt and hash a password.
 * @param password
 * @returns {String} I am the hashed and salted password
 */
function createPassword ( password ) {

	var salt = bcrypt.genSaltSync( 10 );
	var hash = bcrypt.hashSync( password, salt );

	return hash;
};
exports.createPassword = createPassword;


/**
 * I check if a password is correct.
 * @param password
 * @param hash
 * @returns {Boolean} - I return true if it passes, false if it fails.
 */
function checkPassword ( password, hash ) {
	var result = bcrypt.compareSync( password , hash );

	return result;
};
exports.checkPassword = checkPassword;


/* *************************** Private Methods ****************************** */
/**
 * I create a default admin account if there is none.
 */
function createDefaultAdminUser(){

	admin.count().count(function(err, count){

		if(count === 0){
			var newAdmin = new admin({
				username : 'admin',
				password : createPassword('admin')

			});

			newAdmin.save(function(err){
				if(err){
					throw err;
				}
			});
		}
	});
}
