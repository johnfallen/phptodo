/**
 * @fileOverview 	This file handles the server-sided routing.
 * 					You should be able to hit these routes in your
 * 					URL and see data
 * @author 			Hayat Noor <hnoor@bbg.gov>
 * @version 		0.0.1
 * @module 			promo.js
 */

'use strict';

var promo = require('../controllers/promo');


module.exports = function(Promo, app) {

  // Get all promos
  app.route('/promo')
	.get(promo.show);


};
