/**
 * @fileOverview 	This file handles the server-sided routing.
 * 					You should be able to hit these routes in your
 * 					URL and see data
 * @author 			Hayat Noor <hnoor@bbg.gov>
 * @version 		0.0.1
 * @module 			song.js
 */

'use strict';

var song = require('../controllers/song');


module.exports = function(Song, app) {

  // Get all tracks
  app.route('/song')
	.get(song.all);

  app.route('/song/:songId')
	.get(song.show)

	// Update track by id
	.put(song.update);


  app.route('/liked_songs')
    // Get liked on-demand songs
    .get(song.likedSongs);

	// Finish with setting up the songId param
	app.param('songId', song.song);
};
