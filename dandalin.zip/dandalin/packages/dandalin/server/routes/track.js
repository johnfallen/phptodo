/**
 * @fileOverview 	This file handles the server-sided routing.
 * 					You should be able to hit these routes in your
 * 					URL and see data
 * @author 			Hayat Noor <hnoor@bbg.gov>
 * @version 		0.0.1
 * @module 			track.js
 */

'use strict';

var track = require('../controllers/track');


module.exports = function(Track, app) {

  // Get all tracks
  app.route('/track')
	.get(track.all);

  // Route by 'itemCode'
  app.route('/track/:itemCode')
	// Get track by itemCode
    .get(track.show)

	// Update track by 'itemCode' (mostly when user clicks 'Like')
    .put(track.update);

  // Route for getting the current track info from data/player.json
  app.route('/current')
	.get(track.nowPlaying);

  // Get all tracks
  app.route('/liked_tracks')
    .get(track.likedTracks);



  // Finish with setting up the itemCode param
  app.param('itemCode', track.track);
};
