/**
 * @fileOverview 	This file handles the server-sided routing.
 * 					You should be able to hit these routes in your
 * 					URL and see data
 * @author 			Hayat Noor <hnoor@bbg.gov>
 * @version 		0.0.1
 * @module 			sports.js
 */

'use strict';

var sports = require('../controllers/sports');


module.exports = function(Sports, app) {

  // Get all sports data
  app.route('/sports')
	.get(sports.show);


};
