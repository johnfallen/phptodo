/**
 * @fileOverview 	This file handles the server-sided routing.
 * 					You should be able to hit these routes in your
 * 					URL and see data
 * @author 			Hayat Noor <hnoor@bbg.gov>
 * @version 		0.0.1
 * @module 			question_of_the_day.js
 */

'use strict';

var question = require('../controllers/question_of_the_day');


module.exports = function(Question, app) {

  // Get all questions
  app.route('/question')
	.get(question.qotd);


};
