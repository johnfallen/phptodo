/**
 * @fileOverview 	This file handles the server-sided routing.
 * 					You should be able to hit these routes in your
 * 					URL and see data
 * @author 			Hayat Noor <hnoor@bbg.gov>
 * @version 		0.0.1
 * @module 			news.js
 */

'use strict';

var news = require('../controllers/news');


module.exports = function(News, app) {

  // Get all news
  app.route('/news')
		.get(news.show);

  app.route('/news/:newsId')
		.get(news.news);


  // Finish with setting up the songId param
  app.param('newsId', news.news);

};
