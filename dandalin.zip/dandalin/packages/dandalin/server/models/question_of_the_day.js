/**
 * @fileOverview 	I model a Question of the day via Mongoose.
 * @author 			John Allen <jallen@bbg.gov>
 * @version 		0.0.1
 * @module 			question_of_the_day.js
 */
'use strict';

/* *************************** Constructor Code **************************** */
var mongoose = require('mongoose');
var Schema = mongoose.Schema;


/**
 * Question Schema
 */
var QuestionSchema = new Schema({
	active: {
		type: Number,
		required: true,
		default: 1
	},
	question: {
		type: String,
		required: true,
		trim: true
	},
	callOut: {
		type: Array
	},
	comment: {
		type: Array
	},
	created: {
		type: Date,
		default: Date.now
	},
	updated: {
		type: Date,
		default: Date.now
	},
	start: {
		type: Date,
		default: Date.now
	},
	end: {
		type: Date,
		default: Date.now
	}
}, { collection: 'question' });


/* ADDED METHODS */

/**
 * I return an Call Out object that has the default Facebook values.
 * @returns {{text: string, link: string}}
 */
QuestionSchema.methods.getFaceBookCallOut = function() {
	var result = {
		text : 'Vote on Facebook',
		link : 'https://www.facebook.com/dandalinvoa'
	};

	return result;
};

/**
 * I return an empty Call Out object.
 * @returns {{text: string, link: string}}
 */
QuestionSchema.methods.getEmptyCallOut = function() {
	var result = {
		text : '',
		link : ''
	};

	return result;
};


/* Statics */
QuestionSchema.statics.load = function(id, cb) {
	this.findOne({
		_id: id
	}).exec(cb);
};

mongoose.model('Question', QuestionSchema);
