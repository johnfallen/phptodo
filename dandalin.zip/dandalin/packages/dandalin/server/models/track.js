/**
 * @fileOverview 	This is the server-sided model which
 * 					handles the binding to the MongoDB database
 * 					via Mongoose
 * @author 			Hayat Noor <hnoor@bbg.gov>
 * @version 		0.0.1
 * @module 			track.js
 */


'use strict';

/**
 * Module dependencies.
 */
var mongoose = require('mongoose'),
  Schema = mongoose.Schema;


/**
 * Track Schema
 */
var TrackSchema = new Schema({
	created: {
		type: Date,
		default: Date.now
	},
	title: {
		type: String,
		required: true,
		trim: true
	},
	category: {
		type: String,
		required: false,
		trim: true
	},
	artist: {
		type: String,
		required: false,
		trim: true
	},
	comment: {
		type: Array
	},
	like: {
		type: Array
	},
	itemCode: {
		type: String,
		required: true,
		trim: true
	},
	duration: {
		type: String,
		required: false,
		trim: true
	},
	albumArt: {
		type: String,
		required: false,
		trim: true
	},
	active: {
		type: Number,
		required: true,
		default: 1
	}
}, { collection: 'track' });


/**
 * Statics
 */
TrackSchema.statics.load = function(id, cb) {
	this.findOne({
		itemCode: id
	}).exec(cb);
};

mongoose.model('Track', TrackSchema);