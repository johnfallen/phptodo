/**
 * @fileOverview 	I model a on demand song via Mongoose.
 * @author 			John Allen <jallen@bbg.gov>
 * @version 		0.0.1
 * @module 			song.js
 */
'use strict';

/* *************************** Constructor Code **************************** */
var mongoose = require('mongoose');
var Schema = mongoose.Schema;


/**
 * Song Schema
 */
var SongSchema = new Schema({
	active: {
		type: Number,
		required: true,
		default: 1
	},
	albumArt: {
		type: String,
		required: false,
		trim: true
	},
	artist: {
		type: String,
		required: false,
		trim: true
	},
	category: {
		type: Array
	},
	comment: {
		type: Array
	},
	created: {
		type: Date,
		default: Date.now
	},
	duration: {
		type: String,
		required: false,
		trim: true
	},
	itemCode: {
		type: String,
		required: false,
		trim: true
	},
	like: {
		type: Array
	},
	mediaURL : {
		type: String,
		required: true,
		trim: true
	},
	title: {
		type: String,
		required: true,
		trim: true
	}
}, { collection: 'song' });



 /* Statics */

SongSchema.statics.load = function(id, cb) {
	this.findOne({
		_id: id
	}).exec(cb);
};


mongoose.model('Song', SongSchema);