/**
 * @fileOverview 	This is the server-sided controller which
 * 					is all the express functions that handle
 * 					database connectivity via mongoose for News
 * @author 			Hayat Noor <hnoor@bbg.gov>
 * @version 		0.0.1
 * @module 			news.js
 */


'use strict';

/**
 * Module dependencies.
 */
var meanio = require('meanio'),
  config = meanio.config.clean,
  utils = require('../lib/Utils');



/**
 * This function will show the current news
 * @return {Object} Returns the JSON file in data/news.json
 */
exports.show = function(req, res) {
	var jsonPath = config.jsonDataDirectory + '/news.json';
	var data = utils.readJSONFile(jsonPath);

	res.json(data);
};

/**
 * This function will show the current news
 * @return {Object} Returns the JSON file in data/news.json
 */
exports.news = function(req, res) {
	var jsonPath = config.jsonDataDirectory + '/news.json';
	var data = utils.readJSONFile(jsonPath);

	var id = req.params.newsId;
	var newsArticle = '';
	for (var i = 0; i < data.length; i++) {
		if (data[i].link.indexOf(id) > -1) {
			newsArticle = data[i];
		}
	}
	res.json(newsArticle);
};



