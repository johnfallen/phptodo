/**
 * @fileOverview 	This is the server-sided controller which
 * 					is all the express functions that handle
 * 					database connectivity via mongoose
 * @author 			Hayat Noor <hnoor@bbg.gov>
 * @version 		0.0.1
 * @module 			track.js
 */


'use strict';

/**
 * Module dependencies.
 */
var mongoose = require('mongoose'),
  Question = mongoose.model('Question');



/**
 * Get question of the day
 * @return {Object} Returns the current question of the day
 */
exports.qotd = function(req, res) {
	var now = new Date();

	// Add leading zeros to day and month for string generation
	var month = now.getMonth() + 1;
	if (month < 10) {
		month = '0' + month;
	}

	var day = now.getDate();
	if (day < 10) {
		day = '0' + day;
	}

	var stringDate = now.getFullYear() + '-' + month + '-' + day;

//	var today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
//	var tomorrow = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);

	// Range query
//	Question.find({'start': {'$gte': today, '$lt': tomorrow }}).exec(function(err, question) {

	// Query using only the date and ignore the time
	Question.find({ '$where': 'this.start.toJSON().slice(0, 10) == "' + stringDate + '"' }).exec(function(err, question) {
		if (err) {
			return res.json(500, {
				error: 'Cannot list the question of the day'
			});
		}
		res.json(question);

	});
};

