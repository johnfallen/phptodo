/**
 * @fileOverview 	This is the server-sided controller which
 * 					is all the express functions that handle
 * 					database connectivity via mongoose
 * @author 			Hayat Noor <hnoor@bbg.gov>
 * @version 		0.0.1
 * @module 			track.js
 */


'use strict';

/**
 * Module dependencies.
 */
var mongoose = require('mongoose'),
  Track = mongoose.model('Track'),
  _ = require('lodash'),
  meanio = require('meanio'),
  config = meanio.config.clean,
  utils = require('../lib/Utils');





/**
 * Find a track by 'itemCode' parameter
 * @return {Object} Returns the found track or an error message
 * 					if failed.
 */
exports.track = function(req, res, next, itemCode) {
  Track.load(itemCode, function(err, track) {
    if (err) return next(err);
    if (!track) return next(new Error('Failed to load track ' + itemCode));
    req.track = track;
    next();
  });
};

/**
 * This function will update a track
 * @return {Object} Returns the updated track or an error message
 * 					if failed.
 */
exports.update = function(req, res) {
  	var track = req.track;

	track = _.extend(track, req.body);

	track.save(function(err) {
    if (err) {
      return res.json(500, {
        error: 'Cannot update the track'
      });
    }
    res.json(track);

  });
};



/**
 * Show a track
 * @return {Object} Returns a track.
 */
exports.show = function(req, res) {
  res.json(req.track);
};

/**
 * List all tracks
 * @return {Object} Returns all tracks or
 * 					an error message if failed
 */
exports.all = function(req, res) {
	Track.find().exec(function(err, track) {
		if (err) {
			return res.json(500, {
				error: 'Cannot list the tracks'
			});
		}
		res.json(track);

	});
};

/**
 * This function will show what is currently playing
 * @return {Object} Returns the JSON file in data/player.json
 */
exports.nowPlaying = function(req, res) {
	var jsonPath = config.jsonDataDirectory + '/player.json';
	var data = utils.readJSONFile(jsonPath);
	res.json(data);
};

/**
 * Aggregates a list of all liked tracks
 * @return {Object} Returns all tracks or
 * 					an error message if failed
 */
exports.likedTracks = function(req, res) {
	Track.aggregate([
	  {
	    $unwind: '$like'
	  },
	  {
	    $group: {		// grouped by id, artist, title
		  '_id': {
		    'id': '$_id',
		    'title': '$title',
		    'artist': '$artist'
		  },
		  likes: {
		    $sum: 1
		  }
		}
	  },
	  {
	    $sort:{
	      likes: -1	// descending order
	    }
	  }
	]).limit(10).exec(function(err, track) {
		if (err) {
			return res.json(500, {
				error: 'Cannot list the liked tracks'
			});
		}
		res.json(track);
	});
};