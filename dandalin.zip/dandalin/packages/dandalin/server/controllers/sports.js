/**
 * @fileOverview 	This is the server-sided controller which
 * 					is all the express functions that handle
 * 					database connectivity via mongoose for News
 * @author 			Hayat Noor <hnoor@bbg.gov>
 * @version 		0.0.1
 * @module 			sports.js
 */


'use strict';

/**
 * Module dependencies.
 */
var meanio = require('meanio'),
  config = meanio.config.clean,
  request = require('request');



/**
 * This function will show the sports data from the soccer sever
 * @return {Object} Returns the JSON array
 */
exports.show = function(req, res) {
	var url = config.soccerIFrameURL + '/currentgame';


	request(url, function(error, response, body) {

		// try catch this, the remote server may not be up.
		try {
			res.json(JSON.parse(body));
		} catch (e) {
			var emptyArray = '[]';
			res.json( JSON.parse(emptyArray) );
		}
	});

};
