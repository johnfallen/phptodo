/**
 * @fileOverview 	This is the server-sided controller which
 * 					is all the express functions that handle
 * 					database connectivity via mongoose for News
 * @author 			Hayat Noor <hnoor@bbg.gov>
 * @version 		0.0.1
 * @module 			alert.js
 */


'use strict';

/**
 * Module dependencies.
 */
var meanio = require('meanio'),
  config = meanio.config.clean,
  utils = require('../lib/Utils');



/**
 * This function will show the current news
 * @return {Object} Returns the JSON file in data/news_breaking.json
 */
exports.show = function(req, res) {
	var jsonPath = config.jsonDataDirectory + '/' + config.playerItemCodeFlagArray[0].jsonFile;
	var data = utils.readJSONFile(jsonPath);

	res.json(data);
};
