/**
 * @fileOverview 	This is the server-sided controller which
 * 					is all the express functions that handle
 * 					database connectivity via mongoose
 * @author 			Hayat Noor <hnoor@bbg.gov>
 * @version 		0.0.1
 * @module 			song.js
 */


'use strict';

/**
 * Module dependencies.
 */
var mongoose = require('mongoose'),
    _ = require('lodash'),
    Song = mongoose.model('Song');





/**
 * List all songs (on-demand)
 * @return {Object} Returns all songs or
 * 					an error message if failed
 */
exports.all = function(req, res) {
	Song.find().sort('title').exec(function(err, song) {
		if (err) {
			return res.json(500, {
				error: 'Cannot list the on-demand songs'
			});
		}
		res.json(song);

	});
};

/**
 * Find song by id
 */
exports.song = function(req, res, next, id) {
	Song.load(id, function(err, song) {
		if (err) return next(err);
		if (!song) return next(new Error('Failed to load song ' + id));
		req.song = song;
		next();
	});
};

/**
 * Show a song
 */
exports.show = function(req, res) {
	res.json(req.song);
};


/**
 * This function will update a track
 * @return {Object} Returns the updated track or an error message
 * 					if failed.
 */
exports.update = function(req, res) {
	var song = req.song;

	song = _.extend(song, req.body);

	song.save(function(err) {
		if (err) {
			console.log(err);
			return res.json(500, {
				error: 'Cannot update the song'
			});
		}
		res.json(song);

	});
};


/**
 * Aggregates a list of all on-demand songs
 * @return {Object} Returns all on-demand songs or
 * 					an error message if failed
 */
exports.likedSongs = function(req, res) {
	Song.aggregate([
		{
			$unwind: '$like'
		},
		{
			$group: {		// grouped by id, artist, title
				'_id': {
					'id': '$_id',
					'title': '$title',
					'artist': '$artist',
					'duration': '$duration'
				},
				likes: {
					$sum: 1
				}
			}
		},
		{
			$sort:{
				likes: -1	// descending order
			}
		}
	]).limit(10).exec(function(err, song) {
		if (err) {
			return res.json(500, {
				error: 'Cannot list the liked songs'
			});
		}
		res.json(song);
	});
};

