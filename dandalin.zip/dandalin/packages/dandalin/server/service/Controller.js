/** 
 * @fileOverview 	I the controller. I broker the flow of the application.
 * @author 			John Allen <jallen@bbg.gov>
 * @version 		0.0.1
 * @module 			Controller
 */
'use strict';
/* *************************** Required Classes **************************** */
var meanio = require('meanio');
var transformer = require('./TransformerService');
var FayeService = require('./FayeService');
var utils = require('./../lib/Utils');
var log = require('../lib/Logger');
var SongService = require('./SongService');

/* *************************** Constructor Code **************************** */
var config = meanio.config.clean;

/* *************************** Public Methods ****************************** */

/**
 * I do whats necessary after the Dalet Server has posted data.
 * @param {Object} data - I am the incoming data.
 * @return {Boolean} I return true if cool and false if not. 
 */
function handleDaletData( data ){

	transformer.createPlayerJSON( data );

	return true; 
}
exports.handleDaletData = handleDaletData;


/**
 * I do whats necessary after the Dalet Server has posted data.
 * @param {Object} data - I am the incoming data.
 * @return {Boolean} I return true if cool and false if not.
 */
function handleDaletDataCallback( data ){

	FayeService.broadCastFayeData( data, 'player' );

	utils.writeJSONFile( config.jsonDataDirectory + '/player.json', data );

	log.verbose('handleDaletDataCallback was called', data);

	return true;
}
exports.handleDaletDataCallback = handleDaletDataCallback;


/**
 * I do whats necessary after the news has been retrieved from Pangaea.
 * @param {Object} data - I am the incoming data.
 * @return {Boolean} I return true if cool and false if not.
 */
function handlePangaeaNews( data ){

	var oldNewsPath = config.jsonDataDirectory + '/news.json';
	var newNews = transformer.createNewsJSON( data );
	var oldNews = utils.readJSONFile( oldNewsPath );

	if( !utils.simpleObjectCompare( newNews, oldNews ) ){

		FayeService.broadCastFayeData( newNews, 'news' );

		utils.writeJSONFile( oldNewsPath, newNews );

		log.verbose('NEWS was processed from Pangaea');
	}

	return true;
}
exports.handlePangaeaNews = handlePangaeaNews;


/**
 * I pass data from the Pangea service to the Song Service
 * @param {Object} json - I am the OnDemand song data returned from Pangea.
 * @return {Boolean} I return true if cool and false if not.
 */
function handleOnDemandUpdate( json ){

	SongService.importSong( json );

}
exports.handleOnDemandUpdate = handleOnDemandUpdate;

/* *************************** Private Methods ***************************** */
