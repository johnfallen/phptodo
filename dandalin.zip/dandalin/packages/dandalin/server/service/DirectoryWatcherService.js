/** 
 * @fileOverview 	I am a module that watches directories and then calls
 *					the Controller to do something when stuff changes.
 * @author 			John Allen <jallen@bbg.gov>
 * @version 		0.0.1
 * @module 			DirectoryWatcherService
 */
'use strict';

/* *************************** Required Classes **************************** */
var fs = require('fs');

var meanio = require('meanio');
var kue = require('kue');
var chokidar = require('chokidar');
var dom = require('xmldom').DOMParser;

var utils = require('./../lib/Utils');
var controller = require('./Controller');
var log = require('../lib/Logger');

/* *************************** Constructor Code **************************** */
// alias the config data
var config = meanio.config.clean;

// set up the directory watcher
var watcher = chokidar.watch(config.FTPDirectory, {
	persistent: true,
	interval: 10
});

// set up the jobs for kue
var jobs = kue.createQueue();
// how many times should kue try to perform the job?
var howMayJobAttempts = 4;


/* *************************** Public Methods ****************************** */

/**
 * I am the foo method.
 * @return {Boolean} I return true if cool and false if not.
 */
function init(){
	watcher
		.on('add', function( path ) {

			var extension = path.split('.').pop();

			if (extension === 'xml'){

				jobs.create('processDaletData', {
					action : 'add',
					path: path
				}).attempts( howMayJobAttempts ).save();

			}
		})
		.on('change', function( path ) {

			var extension = path.split('.').pop();

			if (extension === 'xml'){

				jobs.create('processDaletData', {
					action : 'change',
					path: path
				}).attempts( howMayJobAttempts ).save();

			}
		})
		.on('unlink', function( path ) {
			//do nothing, we don't care if files have been deleted
		})
		.on('error', function( error ) {
			//ErrorHandler.handleError( 'The watcher borked', error );
		});

	return true;
}
exports.init = init;



/* *************************** Private Methods ***************************** */
/**
 * I am the function called after the watcher sees a change. I read the file
 * make the  JSON and then pass the results to the front controller
 *
 * @param {String} action - what action the watcher performed
 * @param {String} path - the path of the file
 * @return {boolean}
 */
function afterWatcher( action, path ){

	fs.readFile( path, function( err, data ) {

		var xmlDoc = '';
		var json = '';

		// parse the XML
		try {
			xmlDoc = new dom().parseFromString( data.toString() );
		} catch( error ) {
			log.error(error);
		}

		// turn the XML into a JSON object
		try {
			json = utils.xmlToJson( xmlDoc );
		} catch( error ) {
			log.error(error);
		}

		controller.handleDaletData( json );
	});

	return true;
}

/**
 * I process all the jobs in the que. I am the consumer of the Kue.
 *
 * @param {String} 'processJSON' - I am the string to look at the job que for to
 *                                 process things.
 * @param {Function} callback - I am the call back function.
 * @return {Void}
 */
jobs.process('processDaletData', function( job, done ){

	setTimeout(
		function(){
			afterWatcher( job.data.action, job.data.path );
		}, config.fayePushDelay );

	done();
});
