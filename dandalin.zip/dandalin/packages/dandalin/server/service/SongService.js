/**
 * @fileOverview 	I am the API to access Track objects.
 * @author 			John Allen <jallen@bbg.gov>
 * @version 		1.0.0
 * @module 			TrackService
 */
'use strict';
/*jslint unused:false*/

/* *************************** Required Classes **************************** */
var mongoose = require('mongoose');
var log = require('../lib/Logger');
// needs to be loaded so mongoose knows about the model. I have no idea why
var songModel = require('../models/song');
var ErrorHandler = require('../lib/ErrorHandler');

/* *************************** Constructor Code **************************** */
var song = mongoose.model('Song');

/* *************************** Public Methods ****************************** */

/**
 * I take an array of songs and update or save them based on their mediaURL
 * property.
 * @param {Array} songArray - I am the array of songs converted from xml to JSON
 * from Pangea
 */
function importSong( songArray ){

	// alias the array of songs
	var theList = songArray.items.item;

	// loop over and update or delete
	for (var i = 0; i < theList.length; i++) {

		updateOrInsertSong( theList[i] );

	}

	/**
	 * I update or delete a song based on its mediaURL
	 * @param item
	 */
	function updateOrInsertSong( item ){

		// split the title element into 3 things. this is by convention and
		// pangea authors are supposed to do this. the convention is:
		// author - song title - duration
		var infoArray = item.title[0].split('-');

		var updateDate = new Date();

		// set the artist
		var theArtist = '';
		try{
			theArtist = infoArray[0].trim();
		} catch (e){
			// do nothing... the input was janked
		}

		// set the title
		var theTitle = 'undefined';
		try{
			theTitle = infoArray[1].trim();
		} catch (e){
			// do nothing... the input was janked
		}

		// set the duration
		var theDuration = '0:00';
		try{
			theDuration = infoArray[2].trim();
		} catch (e){
			// do nothing... the input was janked
		}

		// make the object of data we will use to insert to update songs with
		var songData = {
			artist : theArtist,
			title : theTitle,
			duration : theDuration,
			mediaURL : item.link[0],
			category : item.category[0].split(','),
			updated : updateDate
		};

		// find it, if there update ELSE save as new.
		song.findOne( { mediaURL : item.link[0] }, function( err, songRetrieved ){

			if( songRetrieved !== null ){

				// We DONT want to update... cause we over write any updates they
				// did in the admin console.
				// This will mean when they delete the song they will have to
				// re-input it into Pangea.

				//songRetrieved.update(songData).exec();
				var superNothingX = 1;
				superNothingX = 0;

			} else {

				var newSong = new song(songData);

				newSong.save(function(err){
					if(err){
						//log.error(err);
						ErrorHandler.handleError('Saving New On Demand Song Failed.', err);
					}
				});
			}
		});

	}
}
exports.importSong = importSong;


/**
 * I return a song by id.
 * @param {String} ID - I am the ID of the song to get
 * @returns {Object} song - the Song that was queried.
 */
function getSong( id, callback, passthroughArgs ){

	song.find( {_id : id },

		function( err, song ){

			if( err ){
				log.error( err );
			}

			callback(song, passthroughArgs);
		}
	);
}
exports.getSong = getSong;
