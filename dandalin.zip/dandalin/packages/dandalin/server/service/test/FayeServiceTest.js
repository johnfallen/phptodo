/**
 * @fileOverview 	I contain all the unit tests for the FayeService.
 * @author 			John Allen <jallen@bbg.gov>
 * @version 		0.0.1
 * @module 			FayeServiceTest
 */
'use strict';
/* *************************** Required Classes **************************** */
var fayService = require('../FayeService');
var assert = require('assert');


console.log('************** HERE *****************!!!!!');


/* *************************** Constructor Code **************************** */

describe('Controller', function() {

	describe('#handleComment should PASS', function () {
		it('should return boolean true.', function () {

			var result = fayService.broadCastFayeData({});

			console.log('************************************');

			console.log(result);

			assert( fayService.broadCastFayeData( {} ) );
		});
	});
});