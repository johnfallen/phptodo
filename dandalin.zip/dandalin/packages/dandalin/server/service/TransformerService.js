/** 
 * @fileOverview 	I transform data into a JSON format the application expects.
 * @author 			John Allen <jallen@bbg.gov>
 * @version 		0.0.1
 * @module 			TransformerService
 */
'use strict';
/* *************************** Required Classes **************************** */
var config = require('../../../../config/env/all');
var log = require('../lib/Logger');
var TrackService = require('./TrackService');
var controller = require('./Controller');
var dandalinApplication = require('./DandalinApplication');

/* *************************** Constructor Code **************************** */
var weAreInBreakingNews = 0;


/* *************************** Public Methods ****************************** */

/**
 * I take raw Pangaea JSON and return a ready to use JSON object
 * @param {Object} news - I am the incoming raw JSON data form Pangaea
 * @returns {Array} I am the array of News items
 */
function createNewsJSON( news ){

	var result = [];

	for (var i = 0; i < news.length; i++) {

		var entry = {};

		// author
		if (news[i].author !== undefined){
			entry.author = news[i].author[0];
		}else{
			entry.author = '';
		}

		// category
		entry.category = news[i].category;

		// get the broken out description and caption
		var captionAndDescription = splitDescriptionAndCaption(news[i].description[0]);

		// caption
		entry.caption = captionAndDescription.caption;

		// description
		entry.description = captionAndDescription.description;

		// image
		if (news[i]._ !== undefined){
			//log.log(news[i]._.trim().replace('http:', ''));

			//entry.image = news[i]._.trim().replace('http:', '');
			entry.image = news[i]._.trim();
		}else{
			entry.image = '';
		}

		// link, pubDate, title
		//entry.link = news[i].link[0].replace('http:', '');
		entry.link = news[i].link[0];
		entry.pubDate = news[i].pubDate[0];
		entry.title = news[i].title[0];

		//log.dump(entry);

		result.push(entry);
	}

	return result;
}
exports.createNewsJSON = createNewsJSON;


/**
 * I take the raw Dalet JSON and transform it into what the application expects.
 * @param {Object} data - I am the incoming data.
 * @return {Boolean} I return true if cool and false if not.
 */
function createPlayerJSON( data ){

	//log.dump('weAreInBreakingNews '  + weAreInBreakingNews);

	var result = {};

	if ( isPlayerStatusActive( data ) && weAreInBreakingNews === 0){

		var isBreakingNews = getCurrentNewsStatus( data );

		if ( isBreakingNews.status ){

			// we will get TWO pushes from dalet, we want to skip the second
			// so we use this variable to keep state.
			if ( weAreInBreakingNews === 0 ){

				// default all the expected nodes
				result.Previous = getSongDefinition();
				result.Current = getSongDefinition();
				result.Next = getSongDefinition();

				result.Current.artistName = isBreakingNews.content.artistName;
				result.Current.titleName = isBreakingNews.content.titleName;
				result.Current.albumName = isBreakingNews.content.titleName;
				result.Current.itemCode = isBreakingNews.content.itemCode;

				//log.dump(result);
				//console.log('WE HAVE FIRED OFF BREAKING NEWS with ITEM CODE: ' + isBreakingNews.content.itemCode);

				controller.handleDaletDataCallback( result );
			}

			// increment this to 1 so the push one will NOT get in this logic.
			weAreInBreakingNews++;

		} else {

			//console.log('weAreInBreakingNews was reset:'  + weAreInBreakingNews);

			log.verbose('active player push');

			var itemCodeArray = [];

			// alias out
			var songData = data.BroadcastMonitor;

			for (var key in songData) {

				if (key === 'Previous' || key === 'Current' || key === 'Next'){

					// some times the item code text is not there.
					try{
						itemCodeArray.push(songData[key].itemCode['#text']);
					} catch( e ) {
						log.error('Error reading Dalet Data.', songData);
						itemCodeArray.push('');
					}
				}
			}

			TrackService.queryTrackByItemCode( itemCodeArray, buildFinalPlayerJSON, data );
		}

		// ok so we have STOPPED because of breaking news. we don't want to push the
		// normal top of the hour news JSON so just reset things...
	} else if ( weAreInBreakingNews === 1 ) {

		weAreInBreakingNews = 0;
	}
	else {

		// default all the expected nodes
		result.Previous = getSongDefinition();
		result.Current = getSongDefinition();
		result.Next = getSongDefinition();

		result.Current.artistName = 'VOA';
		result.Current.titleName = 'News Block';
		result.Current.albumName = 'News Block';

		controller.handleDaletDataCallback( result );
	}

	return true;
}
exports.createPlayerJSON = createPlayerJSON;


/**
 * I take the raw Dalet JSON and queried data and then create the final JSON
 * used in the application.
 * @param {Array} songArray - I am the incoming data.
 * @param {Object} daletData - I am the original raw Dalet JSON data.
 * @return {Object} I return true if cool and false if not.
 */
function buildFinalPlayerJSON(songArray, daletData){

	var result = {};

	// alias out
	var songData = daletData.BroadcastMonitor;

	// create the JSON were going to pass back to the controller
	for (var key in songData) {

		if (key === 'Previous' || key === 'Current' || key === 'Next'){

			var song = getSong( songData[key] );

			result[key] = song;
		}
	}

	// now loop over the results and add data from the query
	for ( var key2 in result ) {

		var itemCodeToMatch = '';

		for (var i = 0; i < songArray.length; i++) {

			itemCodeToMatch = songArray[i].itemCode;

			if ( itemCodeToMatch === result[key2].itemCode ){

				result[key2].artistName = songArray[i].artist;

				break;
			}
		}
	}

	// have the controller deal with the song data
	controller.handleDaletDataCallback( result );

	return true;
}
exports.buildFinalPlayerJSON = buildFinalPlayerJSON;


/* *************************** Private Methods ***************************** */

/**
 * I return a song from the Dalet JSON object.
 * @param {Object} data - I am the Dalet song data to get information from.
 * @return {Object}
 */
function getSong( data ){

	var result = {};
	var songDefinition = getSongDefinition();
	var prop = '';

	for ( var key in songDefinition ) {

		var propertyToCheck = key;

		for ( prop in data ) {

			if (data[propertyToCheck] !== undefined){
				if( data[propertyToCheck]['#text'] !== undefined ) {
					result[ key ] = data[propertyToCheck]['#text'];
				}
				else {
					result[ key ] = '';
				}
			}
		}
	}

	result.isSong = true;

	return result;
}


/**
 * I return the definition of a song... the properties of the XML we want.
 * @returns {Object}
 */
function getSongDefinition() {

	return {
		'artistName': '',
		'titleName': '',
		'albumName': '',
		'ProgramName' : '',
		'CategoryName' : '',
		'BlockName' : '',
		'titleId' : '',
		'itemCode' : '',
		'isSong' : false
	};
}


/**
 * I return if the raw Dalet data is indicating that the song is live or not.
 * @param {Object} daletData - I am the raw Dalet JSON object
 * @returns {boolean}
 */
function isPlayerStatusActive( daletData ){

	var songData = daletData.BroadcastMonitor;
	var result = false;

	try{
		if( songData.playStatus['#text'] !== undefined && songData.playStatus['#text'] === 'PLAYING'){
			result = true;
		}
	} catch(e){ // song data from dalet was borked. wait till next time around.

	}

	return result;
}


/**
 * I check if an itemCode in the Dalet data feed is configured as a breaking or
 * other type of important news story. I return the configured artistName and
 * titleName as an object in my result and a flag if it is a flagged item code.
 * @param {Object} daletData - I am the raw dalet data
 * @returns {Object} - I am the
 */
function getCurrentNewsStatus( daletData ) {

	var result = {};

	result.status = false;

	var flagArray = config.playerItemCodeFlagArray;
	var songData = daletData.BroadcastMonitor;

	var itemCodeToCheck = '';

	// the itemCode is sometimes not there. for breaking news it will always be
	try {
		itemCodeToCheck = songData.Current.itemCode['#text'];
	} catch( e ){
		// do nothing the item code wasn't there
	}


	// loop over the configured array of flagged item codes
	for ( var i = 0; i < flagArray.length; i++ ){

		// is the current song itemCode one we care about?
		if( flagArray[i].itemCode === itemCodeToCheck ) {

			// if it is add the content.
			result.content = flagArray[i];
			result.status = true;

			// set the state of the news
			dandalinApplication.setNewsState(true, flagArray[i].id);

			break;
		}
	}

	// if were not in some sort of breaking news make sure the news state of the
	// application is set to false
	if ( result.status === false ){
		dandalinApplication.setNewsState(false, '');
	}

	return result;
}


/**
 * I return the caption from the description text. This is a 'hack' so we can
 * image credits. Currently the image credit/caption is not included in the
 * feed so were having content creators add a specifically formatted string
 * into the description text area in Pangea. The sting format is:
 * ##caption: this is the caption! ##
 * @param {String} description - I am the text to pull the caption from.
 */
function splitDescriptionAndCaption( description ){

	var result = {};

	var breakout = description.match(/##caption:(.*)##/);

	try{
		result.caption = breakout[1].trim();
		result.description = description.replace(breakout[0], '').trim();
	}
	catch( e ){
		result.caption = '';
		result.description = description;
	}

	return result;
}
