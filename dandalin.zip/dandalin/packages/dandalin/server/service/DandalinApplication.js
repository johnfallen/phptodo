/**
 * @fileOverview 	I am the Dandalin service. I am the main application file
 *                  that kicks off the back end process, brings the application
 *                  to life.
 * @author 			John Allen <jallen@bbg.gov>
 * @version 		0.0.1
 * @module 			DandalinService
 */
'use strict';
/* *************************** Required Classes **************************** */
var meanio = require('meanio');
var log = require('../lib/Logger');
var DirectoryWatcherService = require('./DirectoryWatcherService');
var PangaeaService = require('./PangaeaService');
var utils = require('../lib/Utils');
//var util = require('../lib/Utils');

/* *************************** Constructor Code **************************** */
var config = meanio.config.clean;

// set the state of breaking news in this object. One of it's uses is by the
// front end to determine what to display.
var newsState = {};
newsState.isBreaking = false;
newsState.type = 'breakingNews';

/* *************************** Public Methods ****************************** */

/**
 * I am the the init method.
 * @return {Boolean} I return true if cool and false if not.
 */
function init(){

	initFileSystem();

	DirectoryWatcherService.init();
	PangaeaService.init();

	log.application( 'DANDALIN @ APPLICATION started.', config );

	return true;
}
exports.init = init;


/**
 * I make all of the news_breaking.json file empty strings.
 * @returns {boolean}
 */
function initBreakingNewsJSON(){

	var configObject = getFlaggedNewsJSONObject('breakingNews');

	var pathToWrite = config.jsonDataDirectory + '/' + configObject.jsonFile;

	var news = {
		text: '',
		url: ''
	};

	utils.writeJSONFile(pathToWrite, news);

	return true;
}
exports.initBreakingNewsJSON = initBreakingNewsJSON;


/**
 * I return the stat of news, an object that says the state of news and the tyep
 * of news.
 * @returns {Object} - I am the breaking news state object.
 */
function getNewsState () {
	return newsState;
}
exports.getNewsState = getNewsState;


/**
 * I set the news state object properties.
 * @param {Boolean} isBreaking - I am the flag that states if the news is active
 * @param {String} type - I am the type of news e.g.: breaking, lifestyle.
 */
function setNewsState (isBreaking, type) {
	isBreaking = isBreaking || false;
	type = type || 'breakingNews';

	newsState.isBreaking = isBreaking;
	newsState.type = type;
}
exports.setNewsState = setNewsState;

/* *************************** Private Methods ***************************** */

/**
 * I make sure that required files are in place for the application.
 * @return {boolean}
 */
function initFileSystem(){

	initBreakingNewsJSON();
	initPromoJSON();

	return true;
}

/**
 * I return an object of flagged itemCode objects by type
 * @param {String} id - I am the string in the config object to find me by.
 * @returns {Object} - I am the object found
 */
function getFlaggedNewsJSONObject( id ){

	var playerItemCodeFlagArray = config.playerItemCodeFlagArray;

	var result = {};

	for ( var key in playerItemCodeFlagArray ){

		if ( playerItemCodeFlagArray[key].id === id ){

			result = playerItemCodeFlagArray[key];
		}
	}

	return result;
}

/**
 * I write a default promo JSON file if it is not there.
 * @returns {Boolean} - I return true if I worked.
 */
function initPromoJSON(){

	var defaultJSON = [
		{
			isFullWidth : 'false',
			items :
				[
					{
						link : '',
						image : '',
						text : ''
					},
					{
						link : '',
						image : '',
						text : ''
					}
				]
		},
		{
			isFullWidth : 'false',
			items :
				[
					{
						link : '',
						image : '',
						text : ''
					},
					{
						link : '',
						image : '',
						text : ''
					}
				]
		}
	];

	var path = config.jsonDataDirectory + '/promo.json';

	if ( !utils.fileExists( path ) ){
		utils.writeJSONFile( path, defaultJSON );
	}
}
