/**
 * @fileOverview 	I am the API to access Track objects.
 * @author 			John Allen <jallen@bbg.gov>
 * @version 		1.0.0
 * @module 			TrackService
 */
'use strict';
/*jslint unused:false*/

/* *************************** Required Classes **************************** */
var mongoose = require('mongoose');
var log = require('../lib/Logger');
// needs to be loaded so mongoose knows about the model. I have no idea why
var trackModel = require('../models/track');

/* *************************** Constructor Code **************************** */
var track = mongoose.model('Track');

/* *************************** Public Methods ****************************** */

/**
 * I find an array of Track objects by itemCode and then invoke the passed in
 * callback function.
 * @param {String} itemCode - the itemCode of the track to get
 * @param {Function} callback - the the function to invoke after the query
 * @param {Array} passthroughArgs - an array of arguments to give to the
 * callback function
 */
function queryTrackByItemCode( itemCode, callback, passthroughArgs ){

	var params = [];

	// we will always use $in so make an array if only passed one itemCode
	if ( itemCode instanceof Array ){
		params = itemCode;
	} else {
		params.push( itemCode );
	}

	track.find( {itemCode : {$in : params} },

		function( err, song ){

			if( err ){
				log.error( err );
			}

			callback(song, passthroughArgs);
		}
	);
}
exports.queryTrackByItemCode = queryTrackByItemCode;
