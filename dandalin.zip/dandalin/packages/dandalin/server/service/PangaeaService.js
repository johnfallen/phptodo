/**
 * @fileOverview 	I am the API for the Pangaea CMS.
 * @author 			John Allen <jallen@bbg.gov>
 * @version 		0.0.1
 * @module 			PangaeaService
 */
'use strict';
/* *************************** Required Classes **************************** */
var http = require('http');

var meanio = require('meanio');
var parseString = require('xml2js').parseString;

var controller = require('./Controller');
var log = require('../lib/Logger');
var ErrorHandler = require('../lib/ErrorHandler');


/* *************************** Constructor Code **************************** */
var config = meanio.config.clean;


/* *************************** Public Methods ****************************** */
/**
 * I am the init method. I kick things off
 * @param {Object} data - I am the incoming data.
 * @return {Boolean} I return true if cool and false if not.
 */
function init(){

	// set the news... this will recursively call itself every 5 min.
	setNews();

	// poll for new on demand music, called recursively every 30 min
	setOnDemandMusic();

	return true;
}
exports.init = init;


/**
 * I retrieve news from Pangaea and return it as JSON.
 * @param {Object} data - I am the incoming data.
 * @return {Boolean} I return true if cool and false if not.
 */
function setNews( category ){

	var request = http.get( config.newsURL, function(response) {

		var xml = '';

		response.on('data', function(chunk) {
			xml += chunk;
		});

		response.on('end', function() {

			// replace all returns
			var cleanXML = xml.replace(/[\n\r]/g, '');
			// replace all tabs
			cleanXML = cleanXML.replace(/\t/g, '');
			// replace all spaces more than 2
			cleanXML = cleanXML.replace(/\s{2,}/g, ' ');

			// parse and return the items array
			parseString(cleanXML, function (err, result) {

				if (result.items !== undefined){
					controller.handlePangaeaNews(result.items.item);
				}
			});
		});

		// or can pipe the data to a parser
		//response.pipe(dest);
	});

	request.on('error', function(err) {
		// debug error
	});

	// now recursively call myself every 5 min.
	setTimeout(
		function(){
			setNews();
			log.application('we read the news');
		},
		config.checkNewsInterval
	);

	return true;
}
exports.setNews = setNews;


/**
 * I start the consumption of the On Demand music from Pangea.
 */
function setOnDemandMusic(){

	var request = http.get( config.onDemandMusicFeedURL, function(response) {

		var xml = '';

		response.on('data', function(chunk) {
			xml += chunk;
		});

		response.on('end', function() {

			// parse and return the items array
			parseString(xml, function (err, result) {

				controller.handleOnDemandUpdate(result);
			});
		});

		// or can pipe the data to a parser
		//response.pipe(dest);
	});

	request.on('error', function(err) {
		ErrorHandler.handleError('Error Reading Pangea On Demand Music', err );
	});

	// now recursively call myself every 5 min.

	setTimeout(
		function(){
	        setOnDemandMusic();
			//log.application('we read On Demand');
		},
		config.checkMusicInterval
	);
}
exports.setOnDemandMusic = setOnDemandMusic;

/* *************************** Private Methods ***************************** */

