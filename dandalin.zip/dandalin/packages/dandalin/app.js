/** 
 * @fileOverview 	I am the application file that hooks into the MEAN.io framework.
 * @author 			John Allen <jallen@bbg.gov>
 * @version 		0.0.1
 * @module 			app.js
 */
'use strict';

/* *************************** Required Classes **************************** */
var Module = require('meanio').Module;
var DandalinApplication = require('./server/service/DandalinApplication');

/* *************************** Constructor Code **************************** */
var Dandalin = new Module('Dandalin');

/*
 * All MEAN packages require registration
 * Dependency injection is used to define required modules
 */
Dandalin.register(function(app, auth, database) {

	//We enable routing. By default the Package Object is passed to the routes
	Dandalin.routes(app, auth, database);

	//We are adding a link to the main menu for all authenticated users
	Dandalin.menus.add({
		'title': 'Labarai',		// News
		'link': 'news'
	});

	Dandalin.menus.add({
		'title': 'Labarai Cikin Sauti ',		// News Audio
		'link': 'news/category/labarai_cikin_sauti'
	});

	Dandalin.menus.add({
		'title': 'Rayuwa',		// Lifestyle
		'link': 'news/category/rayuwa'
	});

	Dandalin.menus.add({
		'title': 'Nishadi',		// Entertainment
		'link': 'news/category/nishadi'
	});

	Dandalin.menus.add({
		'title': 'Wasanni',		// Sports
		'link': 'sports'
	});

	Dandalin.menus.add({
		'title': 'Saurari Wakoki', // On Demand
		'link': 'on_demand'
	});
	/*	This is now an admin menu option
	Dandalin.menus.add({
		'title': 'Liked Tracks',
		'link': 'liked_tracks'
	});

	Dandalin.menus.add({
		'title': 'Question of the Day',
		'link': 'qotd'
	});

	Dandalin.menus.add({
		'title': 'Soccer',
		'link': 'soccer'
	});
	*/

	// kick off the Dandalin Service, basically start the application.
	DandalinApplication.init();

    return Dandalin;
});