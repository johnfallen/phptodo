'use strict';

//Setting up route
angular.module('mean.dandalin').config(['$stateProvider',
	function($stateProvider) {
		// states for my app
		$stateProvider
			.state('home', {
				url: '/',
				templateUrl: 'dandalin/views/home.html'
			})
			.state('sports', {
				url: '/sports',
				templateUrl: 'dandalin/views/sports/index.html'
			})
			.state('religion', {
				url: '/religion',
				templateUrl: 'dandalin/views/religion.html'
			})
			.state('news', {
				url: '/news',
				templateUrl: 'dandalin/views/news/list.html'
			})
			.state('news list', {
				url: '/news/browse',
				templateUrl: 'dandalin/views/news/list.html'
			})
			.state('news by audio', {
				url: '/news/category/labarai_cikin_sauti',
				templateUrl: 'dandalin/views/news/list-audio.html'
			})
			.state('news by category', {
				url: '/news/category/:categoryName',
				templateUrl: 'dandalin/views/news/list.html'
			})
			.state('on_demand', {
				url: '/on_demand',
				templateUrl: 'dandalin/views/on_demand/list.html'
			})
			.state('on_demand all', {
				url: '/on_demand/browse',
				templateUrl: 'dandalin/views/on_demand/list.html'
			})
			.state('favorites', {
				url: '/on_demand/favorites',
				templateUrl: 'dandalin/views/on_demand/favorites.html'
			})
			.state('top 10 songs', {
				url: '/on_demand/top10',
				templateUrl: 'dandalin/views/on_demand/top10.html'
			})
			.state('song by id', {
				url: '/song/:songId',
				templateUrl: 'dandalin/views/on_demand/song.html'
			})
			.state('article', {
				url: '/news/:newsId',
				templateUrl: 'dandalin/views/news/article.html'
			})
			.state('liked_tracks', {
				url: '/liked_tracks',
				templateUrl: 'dandalin/views/liked_tracks.html'
			})
			.state('qotd', {
				url: '/qotd',
				templateUrl: 'dandalin/views/qotd.html'
			})
			.state('soccer', {
				url: '/soccer',
				templateUrl: 'dandalin/views/sports/soccer.html'
			})
			.state('schedule', {
				url: '/soccer/schedule',
				templateUrl: 'dandalin/views/sports/schedule.html'
			})
			.state('squads', {
				url: '/soccer/squads',
				templateUrl: 'dandalin/views/sports/squads.html'
			})
			.state('game', {
				url: '/soccer/game/:gameId',
				templateUrl: 'dandalin/views/sports/game.html'
			});

	}
]);

// Set up route change event for Tealium / SiteCatalyst tags
angular.module('mean.dandalin').run(function ($rootScope, $anchorScroll) {

	$rootScope.$on('$locationChangeStart', function (event, next, current) {

		// Reset the news player scrolling anchor when user leaves page
		$rootScope.currentPlayer = null;
		$rootScope.currentPlayerPos = null;

	});

	// When the route changes, scroll user to the top of the page
	$rootScope.$on('$locationChangeSuccess', function() {
		$anchorScroll();
	});

});