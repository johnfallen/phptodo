/**
 * @fileOverview 	This is the track controller that handles everything
 * 					related to track data
 * @author 			Hayat Noor <hnoor@bbg.gov>
 * @version 		0.0.1
 * @module 			track.js
 */

'use strict';

angular.module('mean.dandalin').controller('TrackController', ['$scope', 'Global', 'GetLikedTracks',
	function($scope, Global, GetLikedTracks) {
		$scope.global = Global;

		/**
		 * Grab all liked tracks
		 * @param {Object} response - incoming data from angular service
		 */
		$scope.findLikedTracks = function () {
			GetLikedTracks.then(function (response) {
				$scope.likedTracks = response.data;
			});
		};



	}
]);
