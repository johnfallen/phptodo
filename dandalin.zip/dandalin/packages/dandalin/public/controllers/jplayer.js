/**
 * @fileOverview 	This is the jplayer controller that handles all of the controls
 *					that the player in the footer of the page has.
 * @author 			Hayat Noor <hnoor@bbg.gov>
 * @version 		0.0.1
 * @module 			jplayer.js
 */

/*jslint bitwise: true */
/* global dandalinConfig */
/* global utag */

'use strict';

angular.module('mean.dandalin').controller('JPlayerController', ['$scope', 'Global', '$faye', 'GetCurrentTrackData',
	'$location', 'Track', '$rootScope', 'GetAlert', 'SiteCatalyst',
	function($scope, Global, $faye, GetCurrentTrackData, $location, Track, $rootScope, GetAlert, SiteCatalyst) {
		$scope.global = Global;

		// Audio stream source
		$scope.streamAudio = 'http://voa-21.akacast.akamaistream.net/7/47/322033/v1/ibb.akacast.akamaistream.net/voa-21';

		// This is the variable that will toggle whether the used has voted or not
		$scope.hasVoted = false;


		/**
		 * Method to generate UUID for users (for the sake of voting)
		 * @return {String} Returns the unique identifier
		 */
		$scope.generateUUID = function() {
			var uuid = '';
			'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
				var r = Math.random()*16|0, v = c === 'x' ? r : (r&0x3|0x8);
				uuid += v.toString(16);
			});
			return uuid;
		};

		// Put the object into storage if it doesn't exist
		if (localStorage.getItem('dandalin2') === null) {
			$rootScope.uuid = $scope.generateUUID();
			try {
				localStorage.setItem('dandalin2', $rootScope.uuid);
			} catch (err) {
			//	alert('Your browser does not support localStorage');
			}
		} else {
			$rootScope.uuid = localStorage.getItem('dandalin2');
		}


		/**
		 * Grab inital meta data from data/player.json file
		 * @param {Object} response - incoming data from angular service
		 */
		GetCurrentTrackData.then(function(response) {
			var currentTrack = response.data.Current;

			// Call function to set metadata
			$scope.setMetadata(currentTrack);

			$scope.resultLoaded = true;

		});

		// Subscribe to Faye and listen for new metadata
		var faye = $faye(dandalinConfig.faye.url);

		var oldJson = '';

		/**
		 * Subscribe to Faye push service
		 * @param {Object} response - incoming data from angular service
		 */
		faye.subscribe('/' + dandalinConfig.faye.radioChannel, function(response) {
			var json = JSON.parse(response.text);

			// Check the item code to see if it matches the breaking news item code
			if(json.Current.itemCode === dandalinConfig.itemCodeFlag[0].itemCode) {

				// Get the alert and set the breaking news text / url and display banner
				GetAlert.then(function(alertData) {

					$rootScope.breakingNewsText = alertData.data.text;
					$rootScope.breakingNewsUrl = alertData.data.url;

					// Set the breaking news banner
					$rootScope.isBreakingNews = true;

				});

			} else {
				$rootScope.isBreakingNews = false;
			}

			// Call the function to set metadata
			$scope.setMetadata(json.Current);

			// Reset vote icon
			$scope.hasVoted = false;


			if (response.text === oldJson) {
				var superNothingX = 1;
				superNothingX = 0;
			} else {
				// Call SiteCatalyst Here for everytime faye does a new push
				// but ONLY if the player is playing
				if ($rootScope.isPlaying === true) {
					var utag_data = {
						media_event: 'media_play',
						stream_start: 'no',
						media_action: 'play',
						media_name: $scope.artist + ' - ' + $scope.trackTitle,
						media_type: 'live',
						content_type: 'audio stream'
					};

					utag.link(utag_data);
				}
			}



			oldJson = response.text;
		});


		/**
		 * Method to generate UUID for users (for the sake of voting)
		 * @param {Object} data - incoming data from either Faye subscribe
		 * 						  or initial load
		 */

		$scope.setMetadata = function (data) {
			// Set metadata in scope
			$scope.artist = data.artistName;
			$scope.trackTitle = data.titleName;
			$scope.itemCode = data.itemCode;

		};




		/**
		 * User clicks 'Like' Button for the current track
		 */
		$scope.likeTrack = function () {
			// If the user has already voted, don't let them vote again
			if ($scope.hasVoted === false) {

				// Get the track object from the database by itemCode
				Track.get({
					itemCode: $scope.itemCode
				}, function (trackReturned) {
					$scope.track = trackReturned;

					// value = 1 means it was liked, -1 means dislike
					var like = { uuid: $scope.uuid, date: new Date(), value: 1 };

					// Push the like object to the track object
					$scope.track.like.push(like);


					// Create new track object by passing in scopes track
					var track = $scope.track;
					if (!track.updated) {
						track.updated = [];
					}

					// Provide a new date for updated field
					track.updated = new Date();

					// Call backend to update the object in the database
					track.$update(function () {
						$scope.hasVoted = true;
					});


				});
			}
		};


	}
]);
