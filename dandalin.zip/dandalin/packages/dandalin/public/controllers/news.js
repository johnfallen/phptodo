/**
 * @fileOverview 	This is the news controller that handles everything
 * 					related to news data
 * @author 			Hayat Noor <hnoor@bbg.gov>
 * @version 		0.0.1
 * @module 			news.js
 */

/* global dandalinConfig */

'use strict';

angular.module('mean.dandalin').controller('NewsController', ['$scope', 'Global', 'GetNews', '$location', '$faye',
	'$sce', '$anchorScroll', '$rootScope', 'GetNewsArticle', '$stateParams', '$window', 'SiteCatalystObjectData',
	'SiteCatalyst', '$filter', 'GetNewsCategories',
	function($scope, Global, GetNews, $location, $faye, $sce, $anchorScroll, $rootScope, GetNewsArticle, $stateParams,
		$window, SiteCatalystObjectData, SiteCatalyst, $filter, GetNewsCategories) {
		$scope.global = Global;

		// Get news categories for News Index page
		$scope.home = function () {
			GetNewsCategories.then(function (response) {
				var categories = [];
				for (var i = 0; i < response.length; i++) {

					for (var j = 0; j < response[i].category.length; j++) {
						categories.push(response[i].category[j]);
					}

				}
				var uniqueCategories = $filter('unique')(categories);
				$scope.categories = uniqueCategories;
			});

		};


		/**
		 * Grab news based on filters
		 * @param {Object} response - incoming data from angular service
		 */
		$scope.findNews = function (categoryName) {



			GetNews.then(function (response) {
				var news = $scope.processNewsData(response.data, categoryName);
				$scope.setData(news);
			});





			// Subscribe to Faye and listen for new metadata
			var faye = $faye(dandalinConfig.faye.url);

			/**
			 * Subscribe to Faye push service
			 * @param {Object} response - incoming data from angular service
			 */
			faye.subscribe('/' + dandalinConfig.faye.newsChannel, function(response) {
				var json = JSON.parse(response.text);

				var news = $scope.processNewsData(json, categoryName);

				$scope.setData(news);

			});

		};



		/**
		 *  Loop through the news items and create a scope variable
		 *  for the mp3 links and adjusting image dimensions
		 *  Assign finished product to $scope.news
		 * @param {Object} data - incoming data from inital load or faye
		 */
		$scope.setData = function (data) {

			for (var i = 0; i < data.length; i++) {

				// If the item is an MP3, add a variable to the scope
				if (data[i].link.indexOf('mp3') > -1) {

					// Set up an isAudio flag that will be used in the view
					data[i].isAudio = true;


					// Create a scope variable for the link for jPlayer
					$scope['audio'+i] = data[i].link;

				}

				// Parse the description as HTML and store
			//	data[i].description = $sce.trustAsHtml(data[i].description);

				// Regex to change image dimensions
				data[i].image = $scope.changeImageDimensions(data[i].image);

				data[i].originalUrl = encodeURI(data[i].link);

				// Create an article id from the article URL for routing to specific news article
				data[i].articleId = $filter('stripArticleId')(data[i].link);

				var date = new Date(data[i].pubDate).toISOString().substring(0, 10);
				data[i].pubDateFormatted = date;

			}

			// store full data in this object
			$scope.newsFullDataSet = data;


			// create new scope.news object used for infinite scroll
			$scope.news = [];

			var newsItem = 0;
			$scope.loadMore = function() {
				if (newsItem <= $scope.newsFullDataSet.length) {
					for (var i = 0; i < 5; i++) {
						// push more items
						if ($scope.newsFullDataSet[newsItem]) {
							$scope.news.push($scope.newsFullDataSet[newsItem]);
							newsItem++;
						}

					}
				}
			};

			// load more data
			$scope.loadMore();


			var utag_data = SiteCatalystObjectData.NewsPage;
			utag_data.page_name = $scope.category + ' - index';
			SiteCatalyst.send(utag_data);

		};


		/**
		 * This function changes the dimensions of the passed in image
		 * @param {Object} imageUrl - incoming data from angular service
		 * @return {String} Returns the imageUrl string if it exists or an empty
		 * 					string if it doesn't
		 */
		$scope.changeImageDimensions = function (imageUrl) {
			if (imageUrl.length > 0) {
				// Check browser width and make dimension adjust
				// based on whether it's a mobile device / desktop
				var browserWidth = document.body.offsetWidth;

				// Default dimension
				var dimension = 800;

				// Mobile device
				if (browserWidth < 480) {
					dimension = 260;
				}

				var smallImageUrl = imageUrl.replace(imageUrl.substring(
					// (Where the '_w' is)   (to end of string -4 )  (replace with '_w' and desired dimension)
					imageUrl.indexOf('_w'), imageUrl.length - 4), '_w' + dimension);
				return smallImageUrl;

			} else {
				return '';
			}
		};



		/**
		 * This function goes to the current streaming player
		 */
		$scope.goToCurrentPlayer = function (){
			// set the location.hash to the id of
			// the element you wish to scroll to.

			var currentPlayer = $rootScope.currentPlayer;

			// Scroll to the header of the player instead of actual player for better view
			var divToScrollTo = 'item-' + currentPlayer.split('-')[2];

			$location.hash(divToScrollTo);

			// call $anchorScroll()
			$anchorScroll();
		};

		/**
		 * Grab article by id
		 * @param {Object} response - incoming data from angular service
		 */
		$scope.findNewsArticle = function () {
			var newsId = $stateParams.newsId;
			GetNewsArticle.query(newsId).then(function (response) {
				$scope.news = response.data;
				$scope.description = $sce.trustAsHtml($scope.news.description);

				// Get a smaller image if small screen size (mobile)
				$scope.news.image = $scope.changeImageDimensions($scope.news.image);


				// Set the share Url for Facebook, Twitter, Google+, WhatsApp sharing
				//	$scope.song.shareURL = encodeURIComponent($location.$$absUrl);
				$scope.news.shareURL = $location.$$absUrl;

				var date = new Date($scope.news.pubDate).toISOString().substring(0, 10);
				$scope.news.pubDateFormatted = date;


				var utag_data = SiteCatalystObjectData.Article;
				utag_data.page_name = $scope.news.title;
				utag_data.page_type = $scope.news.articleId;
				utag_data.section = 'News';

				var dateArr = $scope.news.pubDateFormatted.split('-');

				utag_data.pub_year = dateArr[0];
				utag_data.pub_month = dateArr[1];
				utag_data.pub_day = dateArr[2];
				SiteCatalyst.send(utag_data);

				// Try to parse out MP3 file
				try {
					if ($scope.news.link.indexOf('mp3') > -1) {
						$scope.isAudio = true;
						$scope.audio = $scope.news.link;
					}
				// If the $scope.news.link is not found, the article no longer exists
				// in the News Feed so redirect to the original article link found in the URL
				} catch(e) {
					var redirectUrl = decodeURIComponent($location.$$url.split('original=')[1]);
					$window.location.href = redirectUrl;
				}


			});

		};


		$scope.processNewsData = function (response, categoryName) {
			// Try to pull in the category from the HTML function call
			// If it's undefined, look for it in the queryString Params
			// if they are both undefined, then show all categories

			var category = '';
			var categoryItems = [];

			// this condition is only for the regular labarai news page
			if (categoryName === undefined && $stateParams.categoryName === undefined && $location.$$url.indexOf('labarai_cikin_sauti') === -1) {

				$scope.category = 'labarai';
				return response;


			// There is a specified category
			} else {
											  // this condition is for the labarai_cikin_sauti category as it has a separate view
				if (categoryName === undefined && $location.$$url.indexOf('labarai_cikin_sauti') === -1) {
					categoryName = $stateParams.categoryName;

				// make sure it's not wasanni either
				} else if (categoryName !== 'wasanni') {
					categoryName = 'labarai cikin sauti';
				}

				category = $filter('removeUrlUnderScore')(categoryName);

				categoryItems = [];

				for (var i = 0; i < response.length; i++) {
					if(response[i].category.toString().toLowerCase().indexOf(category) > -1) {
						categoryItems.push(response[i]);
					}
				}

				$scope.category = category;
				return categoryItems;



			}
		};




	}
]);
