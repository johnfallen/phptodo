/**
 * @fileOverview 	This is the song controller that handles everything
 * 					related to sports (wasanni)
 * @author 			Hayat Noor <hnoor@bbg.gov>
 * @version 		0.0.1
 * @module 			sports.js
 */
/* global dandalinConfig */

'use strict';

angular.module('mean.dandalin').controller('SportsController', ['$scope', 'Global', 'GetSportsData', '$location', '$sce',
	function($scope, Global, GetSportsData, $location, $sce) {
		$scope.global = Global;

		$scope.findSportsData = function () {
			GetSportsData.then(function (response) {
				$scope.sports = response.data;
			});
		};

		// This function trusts the URL for the dynamic iframe loading
		$scope.trustSrc = function(src) {
			return $sce.trustAsResourceUrl(src);
		};


		$scope.grabURL = function () {

			// this could be undefined, but only one view looks for it the game view.
			var gameId = $location.$$url.split('/')[3];

			$scope.url = dandalinConfig.soccerIFrameURL;
			$scope.gameId = gameId;
		};
	}
]);
