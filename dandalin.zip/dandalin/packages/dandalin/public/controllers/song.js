/**
 * @fileOverview 	This is the song controller that handles everything
 * 					related to song (on-demand) data
 * @author 			Hayat Noor <hnoor@bbg.gov>
 * @version 		0.0.1
 * @module 			song.js
 */

'use strict';



angular.module('mean.dandalin').controller('SongController', ['$scope', 'Global', 'Songs', '$stateParams', 'Song',
	'$rootScope', '$filter', '$location', 'SiteCatalystObjectData', 'SiteCatalyst',
	function($scope, Global, Songs, $stateParams, Song, $rootScope, $filter, $location, SiteCatalystObjectData,
			 SiteCatalyst) {
		$scope.global = Global;


		// This is the variable that will toggle whether the used has voted or not
		$scope.hasVoted = false;

		// This is the variable that will determine whether a user has added a particular song to their favorites
		$scope.addedToFavorites = false;

		// Set up order filter for table
		var orderBy = $filter('orderBy');

		$scope.order = function(predicate, reverse) {
			$scope.songs = orderBy($scope.songs, predicate, reverse);
		};

		/**
		 *	Home / Index Page for On-Demand
		 */
		$scope.home = function () {
			var utag_data = SiteCatalystObjectData.OnDemandPage;
			SiteCatalyst.send(utag_data);
		};




		/**
		 * Grab all songs on inital load
		 * @param {Object} response - incoming data from angular service
		 */
		$scope.findSongs = function () {
			Songs.getAll().then(function (response) {
				$scope.songs = response.data;

				var utag_data = SiteCatalystObjectData.OnDemandSongs;
				SiteCatalyst.send(utag_data);
			});
		};


		/**
		 * Grab song by id
		 * @param {Object} response - incoming data from angular service
		 */
		$scope.findSong = function () {
			Song.get({
				songId: $stateParams.songId
			}, function(song) {

				$scope.song = song;

				// default the album art if there is none.
				if ($scope.song.albumArt.length === 0){
					$scope.song.albumArt = '/dandalin/assets/img/albumart.png';
				}

				$scope.audio0 = $scope.song.mediaURL;

				// Set the share Url for Facebook, Twitter, Google+, WhatsApp sharing
			    //	$scope.song.shareURLEncoded = encodeURIComponent($location.$$absUrl);
				$scope.song.shareURL = $location.$$absUrl;


				// Loop through the likes and see if the like has
				// a UUID that matches the current user's UUID
				for (var i = 0; i < $scope.song.like.length; i++) {
					if ($scope.song.like[i].uuid === $rootScope.uuid) {

						// Set hasVoted to true so the like button cannot be hit again
						$scope.hasVoted = true;

					}
				}
				/*
				var utag_data = SiteCatalystObjectData.SongDetail;
				utag_data.page_name =  $scope.song.artist + ' - ' + $scope.song.title;
				SiteCatalyst.send(utag_data);
				*/

				var favoritedSongs = JSON.parse(localStorage.getItem('dandalin2-favorites'));
				if (favoritedSongs) {
					for (var j = 0; j < favoritedSongs.length; j++) {
						if ($scope.song._id === favoritedSongs[j]._id) {
							$scope.addedToFavorites = true;
						}
					}
				}

				$scope.songLoaded = true;




			});
		};


		/**
		 * This method finds the Top 10 songs by likes
		 * @param {Object} response - incoming data from angular service
		 */

		$scope.findTop10Songs = function () {
			Songs.getTop10().then(function (response) {
				$scope.songs = response.data;

				var utag_data = SiteCatalystObjectData.OnDemandTop10Songs;
				SiteCatalyst.send(utag_data);
			});
		};


		/**
		 * User clicks 'Like' Button for the current on-demand song
		 */
		$scope.likeSong = function () {

			 // If the user has already voted, don't let them vote again
			 if ($scope.hasVoted === false) {

				 // value = 1 means it was liked, -1 means dislike
				 var like = { uuid: $scope.uuid, date: new Date(), value: 1 };

				 // Push the like object to the song object
				 $scope.song.like.push(like);

				 // Create new track object by passing in scopes track
				 var song = $scope.song;
				 if (!song.updated) {
					song.updated = [];
				 }

				 // Provide a new date for updated field
				 song.updated = new Date();

				 // Call backend to update the object in the database
				 song.$update(function () {
					$scope.hasVoted = true;
				 });

			 }

		};

		/**
		 * User clicks 'Favorites' Button for the current on-demand song
		 */
		$scope.addToFavorites = function () {


			// If the user has already voted, don't let them vote again
			if ($scope.addedToFavorites === false) {

				var songs = [];
				if (localStorage.getItem('dandalin2-favorites') === null) {
					songs.push($scope.song);
					localStorage.setItem('dandalin2-favorites', JSON.stringify(songs));
				} else {

					// Parse the serialized data back into an aray of objects
					songs = JSON.parse(localStorage.getItem('dandalin2-favorites'));

					var alreadyLikedSong = false;

					for (var i = 0; i < songs.length; i++) {
						if ($scope.song._id === songs[i]._id) {
							alreadyLikedSong = true;
						}
					}

					if (alreadyLikedSong === false) {
						// Push the new data (whether it be an object or anything else) onto the array
						songs.push($scope.song);

						// Re-serialize the array back into a string and store it in localStorage
						localStorage.setItem('dandalin2-favorites', JSON.stringify(songs));
					}

				}


				$scope.addedToFavorites = true;


			}

		};


		/**
		 * This method finds the users favorited songs by localStorage
		 * @param {Object} response - localStorage object with favorited songs
		 */

		$scope.findFavoritedSongs = function () {
			$scope.songs = JSON.parse(localStorage.getItem('dandalin2-favorites'));
		};
	}
]);
