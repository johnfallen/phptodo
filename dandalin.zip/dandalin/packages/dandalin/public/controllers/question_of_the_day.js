/**
 * @fileOverview 	This is the song controller that handles everything
 * 					related to Question of the Day
 * @author 			Hayat Noor <hnoor@bbg.gov>
 * @version 		0.0.1
 * @module 			question_of_the_day.js
 */

'use strict';

angular.module('mean.dandalin').controller('QuestionController', ['$scope', 'Global', 'GetQuestionOfTheDay',
	'$rootScope', 'SiteCatalystObjectData', 'SiteCatalyst',
	function($scope, Global, GetQuestionOfTheDay, $rootScope, SiteCatalystObjectData, SiteCatalyst) {
		$scope.global = Global;

		$scope.findQuestionOfTheDay = function () {

			GetQuestionOfTheDay.then(function(response) {

				$scope.question = response.data[0];

				var utag_data = SiteCatalystObjectData.QuestionOfTheDay;
				utag_data.page_name = $scope.question.question;
				SiteCatalyst.send(utag_data);


			});

		};




	}
]);
