/**
 * @fileOverview 	This is the song controller that handles everything
 * 					related to alerts (breaking news, lifestyle, sports, etc.)
 * @author 			Hayat Noor <hnoor@bbg.gov>
 * @version 		0.0.1
 * @module 			alert.js
 */

/* global dandalinConfig */

'use strict';

angular.module('mean.dandalin').controller('AlertController', ['$scope', 'Global', '$faye', '$rootScope', 'GetAlert',
	function($scope, Global, $faye, $rootScope, GetAlert) {
		$scope.global = Global;

		// Subscribe to Faye and listen for new metadata
		var faye = $faye(dandalinConfig.faye.url);

		// Grab app status from config file
		$rootScope.isBreakingNews = dandalinConfig.newsState.isBreaking;

		// on page load
		if ($rootScope.isBreakingNews === true) {
			GetAlert.then(function (response) {
				$rootScope.breakingNewsText = response.data.text;
				$rootScope.breakingNewsUrl = response.data.url;
			});
		}

		/**
		 * Subscribe to Faye push service for Breaking News
		 * @param {Object} response - incoming data from angular service
		 */
		faye.subscribe('/' + dandalinConfig.faye.breakingNewsChannel, function(response) {
			var json = JSON.parse(response.text);

			$rootScope.breakingNewsText = json.text;
			$rootScope.breakingNewsUrl = json.url;

			// Set the breaking news banner
			$rootScope.isBreakingNews = true;

		});

		/**
		 * Subscribe to Faye push service for Breaking News
		 * @param {Object} response - incoming data from angular service
		 */
		faye.subscribe('/' + dandalinConfig.faye.breakingNewsChannel, function(response) {
			var json = JSON.parse(response.text);

			$rootScope.breakingNewsText = json.text;
			$rootScope.breakingNewsUrl = json.url;

			// Set the breaking news banner
			$rootScope.isAlertNews = true;

		});





	}
]);
