/**
 * @fileOverview 	This controller is for the home page of Dandalin
 * @author 			Hayat Noor <hnoor@bbg.gov>
 * @version 		0.0.1
 * @module 			home.js
 */

'use strict';

angular.module('mean.dandalin').controller('HomeController', ['$scope', 'Global', 'SiteCatalystObjectData',
	'SiteCatalyst', 'GetNewsForHomePage', '$filter', 'GetQuestionOfTheDay', '$location', 'Songs', 'GetPromo',
	function($scope, Global, SiteCatalystObjectData, SiteCatalyst, GetNewsForHomePage, $filter, GetQuestionOfTheDay, $location,
		Songs, GetPromo) {
		$scope.global = Global;


		GetNewsForHomePage.then(function (response) {
			$scope.newsStoryOne = response.data[0];
			$scope.newsStoryOne.image = $scope.changeImageDimensions($scope.newsStoryOne.image);
			$scope.newsStoryOne.articleId = $filter('stripArticleId')(response.data[0].link);

			$scope.newsStoryTwo = response.data[1];
			$scope.newsStoryTwo.image = $scope.changeImageDimensions($scope.newsStoryTwo.image);
			$scope.newsStoryTwo.articleId = $filter('stripArticleId')(response.data[1].link);

			$scope.newsStoryThree = response.data[2];
			$scope.newsStoryThree.image = $scope.changeImageDimensions($scope.newsStoryThree.image);
			$scope.newsStoryThree.articleId = $filter('stripArticleId')(response.data[2].link);

			// Register a home view
		//	var utag_data = SiteCatalystObjectData.Home;
		//	SiteCatalyst.send(utag_data);
		});

		GetQuestionOfTheDay.then(function(response) {

			$scope.question = response.data[0];
			$scope.isQuestionOfTheDay = true;
			if ($scope.question.question === 'There is no question of the day for today.') {
				$scope.isQuestionOfTheDay = false;

				/**
				 * This method finds the Top 10 songs (by likes), but only grabs the first one
				 * for the home page
				 * @param {Object} response - incoming data from angular service
				 */
				Songs.getTop10().then(function (response) {
					$scope.topSong = response.data[0];
				});


			}
			if ($scope.question.callOut && $scope.question.callOut[0]) {
				$scope.question.callOutLink = $scope.question.callOut[0].link;
			}

			/*
			// register a QOTD view
			var utag_data = SiteCatalystObjectData.QuestionOfTheDay;
			utag_data.page_name = $scope.question.question;
			SiteCatalyst.send(utag_data);
			*/

		});

		//  Get promotional data from back-end
		GetPromo.then(function(response) {

			// The first item in the array is designated for the top promo space
			$scope.topPromo = response.data[0];

			// The second item in the array is designated for the bottom promo space
			$scope.bottomPromo = response.data[1];

		});






		$scope.redirect = function(page) {
			$location.url(page);
		};


		$scope.changeImageDimensions = function (imageUrl) {
			var widthDimension = 350;
			var heightDimension = 350;

			var smallImageUrl = imageUrl.replace(imageUrl.substring(
				// (Where the '_w' is)   (to end of string -4 )  (replace with '_w' and desired dimension)
				imageUrl.indexOf('_w'), imageUrl.length - 4), '_w' + widthDimension + '_h' + heightDimension);
			return smallImageUrl;


		};







	}
]);
