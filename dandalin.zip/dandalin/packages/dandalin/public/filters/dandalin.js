/**
 * Angular Filters for Dandalin App
 */

'use strict';

angular.module('mean.dandalin').filter('nigerianDate', function() {
	return function(timestamp) {
		var date = new Date(timestamp);
		var dateString = date.toISOString().substring(0, 10).replace('-', '.').replace('-', '.');
		return dateString;
	};
});

angular.module('mean.dandalin').filter('stripArticleId', function() {
	return function(url) {
		// Create an article id from the article URL for routing to specific news article
		var linkSplitArray = url.split('/');
		var endOfLink = linkSplitArray[linkSplitArray.length - 1];
		var articleId = endOfLink.split('.')[0];

		return articleId;
	};
});

// unique items in array
angular.module('mean.dandalin').filter('unique', function() {

	return function (arr) {
		var o = {}, i, l = arr.length, r = [];
		for(i=0; i<l;i+=1) {
			o[arr[i]] = arr[i];
		}
		for(i in o) {
			r.push(o[i]);
		}
		return r;
	};
});

// add underscore to string
angular.module('mean.dandalin').filter('urlUnderScore', function() {

	return function (string) {
		return string.split(' ').join('_');
	};
});

// remove underscore from string
angular.module('mean.dandalin').filter('removeUrlUnderScore', function() {

	return function (string) {
		if(string) {
			return string.split('_').join(' ');
		}
	};
});

// return parent category from category array
angular.module('mean.dandalin').filter('parentCategory', function() {

	return function (category) {
		var parentCategory = category[0];

		if (parentCategory.indexOf('Labarai') > -1) {
			return 'labarai-top-story';


		} else if (parentCategory.indexOf('Rayuwa') > -1) {
			return 'rayuwa-top-story';


		} else if (parentCategory.indexOf('Wasanni') > -1) {
			return 'wasanni-top-story';


		} else if (parentCategory.indexOf('Nishadi') > -1) {
			return 'nishadi-top-story';

		} else {
			return 'default-top-story';
		}

	};
});

// show most specific category
angular.module('mean.dandalin').filter('specificCategory', function() {

	return function (category) {
		return category[category.length - 1];

	};
});

// angular filter for formatting duration nigerian style
angular.module('mean.dandalin').filter('formatDuration', function() {

	return function (duration) {
		if (duration.indexOf('"') > -1) {
			return duration;
		} else {
			return duration.replace(':', '\'') + '"';
		}

	};
});




