/**
 * @fileOverview 	This is the track service that handles all
 * 					REST calls for the song
 * @author 			Hayat Noor <hnoor@bbg.gov>
 * @version 		0.0.1
 * @module 			song.js
 */

'use strict';

/**
 * Method that gets songs (on-demand) from the 'song' collection
 * @return {Object} Returns the JSON object to the controller
 */
angular.module('mean.dandalin').factory('Songs', ['$http', function ($http) {
	var songs = {
		// Get all of the songs
		getAll: function (id) {
			return $http.get('song').then(function(response) {
				return response;
			});
		},
		// Get the Top 10 songs
		getTop10: function (id) {
			return $http.get('liked_songs').then(function(response) {
				return response;
			});
		}
	};
	return songs;
}]);


//Articles service used for articles REST endpoint
angular.module('mean.dandalin').factory('Song', ['$resource',
	function($resource) {
		return $resource('song/:songId', {
			songId: '@_id'
		}, {
			update: {
				method: 'PUT'
			}
		});
	}
]);


