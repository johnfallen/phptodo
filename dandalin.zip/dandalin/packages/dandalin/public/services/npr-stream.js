'use strict';

// Service to get metadata
angular.module('mean.dandalin').factory('GetMetadata', ['$http',
	function($http) {
		return $http.get('http://apps.innovation-series.com/streamreader/remote.streaminfo.php?l=http://sc9.iad.llnw.net/stream/npr_music2').then(function(response) {
			return response;
		});
	}
]);

