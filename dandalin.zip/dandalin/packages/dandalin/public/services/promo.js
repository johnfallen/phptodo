/**
 * @fileOverview 	This is the track service that handles all
 * 					REST calls for the alerts
 * @author 			Hayat Noor <hnoor@bbg.gov>
 * @version 		0.0.1
 * @module 			promo.js
 */

'use strict';

/**
 * Method that gets the current track data from data/promo.json
 * @return {Object} Returns the JSON object to the controller
 */
angular.module('mean.dandalin').factory('GetPromo', ['$http',
	function($http) {
		return $http.get('promo').then(function(response) {
			return response;
		});
	}
]);

