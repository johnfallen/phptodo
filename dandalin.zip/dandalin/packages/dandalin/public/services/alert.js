/**
 * @fileOverview 	This is the track service that handles all
 * 					REST calls for the alerts
 * @author 			Hayat Noor <hnoor@bbg.gov>
 * @version 		0.0.1
 * @module 			alert.js
 */

'use strict';

/**
 * Method that gets the current track data from data/player.json
 * @return {Object} Returns the JSON object to the controller
 */
angular.module('mean.dandalin').factory('GetAlert', ['$http',
	function($http) {
		return $http.get('alert').then(function(response) {
			return response;
		});
	}
]);

