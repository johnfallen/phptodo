/**
 * @fileOverview 	This is the track service that handles all
 * 					REST calls for the alerts
 * @author 			Hayat Noor <hnoor@bbg.gov>
 * @version 		0.0.1
 * @module 			alert.js
 */

'use strict';

/**
 * Method that gets the Question of the Day
 * @return {Object} Returns the JSON object to the controller
 */
angular.module('mean.dandalin').factory('GetQuestionOfTheDay', ['$http',
	function($http) {
		return $http.get('question').then(function(response) {
			if(response.data.length > 0) {
				return response;
			} else {
				response = {
					data: [
						{
							question: 'There is no question of the day for today.'
						}
					]
				};
				return response;
			}

		});
	}
]);

