/**
 * @fileOverview 	This is the track service that handles all
 * 					REST calls for the track as well as pulling
 * 					initial metadata for the player
 * @author 			Hayat Noor <hnoor@bbg.gov>
 * @version 		0.0.1
 * @module 			track.js
 */

'use strict';

//Articles service used for articles REST endpoint
angular.module('mean.dandalin').factory('Track', ['$resource',
  function($resource) {
    return $resource('track/:itemCode', {
      itemCode: '@itemCode'
    }, {
      update: {
        method: 'PUT'
      }
    });
  }
]);

/**
 * Method that gets the current track data from data/player.json
 * @return {Object} Returns the JSON object to the controller
 */
angular.module('mean.dandalin').factory('GetCurrentTrackData', ['$http',
	function($http) {
		return $http.get('current').then(function(response) {
			return response;
		});
	}
]);

/**
 * Method that gets the liked tracks from the database
 * @return {Object} Returns the JSON object to the controller
 */
angular.module('mean.dandalin').factory('GetLikedTracks', ['$http',
	function($http) {
		return $http.get('liked_tracks').then(function(response) {
			return response;
		});
	}
]);
