'use strict';

/* global utag */


/**
 * Method that stores the SiteCatalyst Mapping
 * @return {Object} Returns the JSON object to the angular route
 */


angular.module('mean.dandalin').factory('SiteCatalystObjectData', function () {
	var sc = {
		Home : {				// /
			page_type: 'home',
			page_name: 'dandalin homepage',
			content_type: 'home',
			section: 'home'
		},
		NewsPage : {
			page_type: 'section',
			page_name: 'news',
			content_type: 'section',
			section: 'news'
		},
		EntertainmentPage : {
			page_type: 'section',
			page_name: 'entertainment',
			content_type: 'section',
			section: 'entertainment'
		},
		LifestylePage : {
			page_type: 'section',
			page_name: 'lifestyle',
			content_type: 'section',
			section: 'lifestyle'
		},
		SportsPage : {
			page_type: 'section',
			page_name: 'sports',
			content_type: 'section',
			section: 'sports'
		},
		Article : {				// news/[ARTICLE_ID]?original=[ORIGINAL_ARTICLE_URL]
			page_type: '',				// ARTICLE_ID
			page_name: '',				// [HEADLINE FROM PANGEA]
			content_type: 'article',
			section: ''					// [ENGLISH SECTION FROM PANGEA]
		},
		VideoLibrary : {
			page_type: 'section',
			page_name: 'Video Library',
			content_type: 'navigation',
			section: 'video'
		},
		VideoDetail : {
			page_type: 'video',
			page_name: '[HEADLINE FROM PANGEA]',
			content_type: 'video',
			section: 'video'
		},
		SongDetail : {			// song/[SONG_ID]
			page_type: 'audio',
			page_name: '[SONG NAME FROM PANGEA]',
			content_type: 'audio',
			section: 'on-demand songs'
		},
		ImageGalleryHome : {
			page_type: 'section',
			page_name: 'Image Galleries',
			content_type: 'navigation',
			section: 'news'
		},
		ImageGallery : {
			page_type: 'photo gallery',
			page_name: '[GALLERY NAME FROM PANGEA]',
			content_type: 'photo gallery',
			section: '[ENGLISH SECTION FROM PANGEA]'
		},
		QuestionOfTheDay : {		// qotd
			page_type: 'Question of the day',	// inconsistent with section
			page_name: '',						// [NAME OF QUESTION]
			content_type: 'user interaction',
			section: 'Question of the Day'		// inconsistent with page_type
		},
		OnDemandPage : {			// on_demand
			page_type: 'section',
			page_name: 'Home - On Demand Audio',
			content_type: 'navigation',
			section: 'on-demand songs'
		},
		OnDemandSongs : {			// on_demand/browse
			page_type: 'section',
			page_name: 'Browse - On Demand Audio',
			content_type: 'navigation',
			section: 'on-demand songs'
		},
		OnDemandTop10Songs : {		// on_demand/top10
			page_type: 'section',
			page_name: 'Top 10 - On Demand Audio',
			content_type: 'navigation',
			section: 'on-demand songs'
		}
	};

	return sc;
});


// This is an angular service that will get the utag_data from the controllers and
// send to SiteCatalyst
angular.module('mean.dandalin').factory('SiteCatalyst', function (SiteCatalyst) {
	var siteCatalyst = {

		send: function (utagData) {

			utag.data.page_type = utagData.page_type;
			utag.data.page_name = utagData.page_name;
			utag.data.content_type = utagData.content_type;
			utag.data.section = utagData.section;

			utag.view(utag.data);


		},

		link: function (utagData) {
			try {
				utag.link(utagData);
			}
			catch(err) {
				console.log(err.message);
			}

		}
	};

	return siteCatalyst;

});



