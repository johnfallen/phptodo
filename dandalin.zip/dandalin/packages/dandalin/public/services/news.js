/**
 * @fileOverview 	This is the track service that handles all
 * 					REST calls for the news
 * @author 			Hayat Noor <hnoor@bbg.gov>
 * @version 		0.0.1
 * @module 			news.js
 */

'use strict';

/**
 * Method that gets the current track data from data/player.json
 * @return {Object} Returns the JSON object to the controller
 */
angular.module('mean.dandalin').factory('GetNews', ['$http',
	function($http) {
		return $http.get('news').then(function(response) {
			return response;
		});
	}
]);

/**
 * Method that gets the current track data from data/player.json
 * and filters out the mp3 files
 * @return {Object} Returns the JSON object to the controller
 */
angular.module('mean.dandalin').factory('GetNewsForHomePage', ['$http',
	function($http) {
		return $http.get('news').then(function(response) {

			// Create a newsFiles object only
			var newsFiles = {
				data: []
			};

			// Loop through the news items and throw only the HTML pages
			// into the new data object
			for (var i = 0; i < response.data.length; i++) {
				if (response.data[i].link.indexOf('.mp3') < 1) {
					newsFiles.data.push(response.data[i]);
				}
			}

			return newsFiles;
		});
	}
]);



/**
 * Method that gets the current track data from data/player.json
 * @return {Object} Returns the catgories JSON object to the controller
 */
angular.module('mean.dandalin').factory('GetNewsCategories', ['$http',
	function($http) {
		return $http.get('news').then(function(response) {
			return response.data;
		});
	}
]);

//Articles service used for articles REST endpoint
angular.module('mean.dandalin').factory('GetNewsArticle', ['$http', function ($http) {
	var article = {

		query: function (id) {
			return $http.get('news/'+id).then(function(response) {
				return response;
			});
		}
	};
	return article;
}]);

