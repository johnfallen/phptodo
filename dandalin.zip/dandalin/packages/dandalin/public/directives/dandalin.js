'use strict';
/* global FB */
/* global $ */
/* global utag */

// Directive for jPlayer Controls
angular.module('mean.dandalin').directive('jplayer', function($rootScope) {
	return {
		restrict: 'EA',
		template: '<div></div>',
		link: function(scope, element, attrs) {
			var $control = element,
				$player = $control.children('div'),
				cls = 'glyphicon-pause',
				liveStreamPlayer = 'jplayer-control';



			var calcTime = function (time) {
				var minutes = Math.floor(time / 60);
				var seconds = Math.floor(time - minutes * 60);

				if (seconds < 10) {
					seconds = '0' + seconds;
				}

				// formatting using nigerian duration 6'43" is 6:43
				return minutes + '\'' + seconds + '"';
			};

			var updatePlayer = function() {
				$player.jPlayer({
					// Flash fallback for outdated browser not supporting HTML5 audio/video tags
					// http://jplayer.org/download/
					swfPath: 'js/jplayer/',
					supplied: 'mp3',
					solution: 'html, flash',
					preload: 'metadata',			// use 'none' to disable preloading
					wmode: 'window',
					remainingDuration: true,
					toggleDuration: true,
					ready: function () {
						$player
							.jPlayer('setMedia', {mp3: scope.$eval(attrs.audio)})
							.jPlayer(attrs.autoplay === 'false' ? 'play' : 'pause');
					},
					/**
					 * Event handler for when jPlayer track is ready
					 * This function's purpose is to populate the duration for inline player
					 * @param {Object} event - jPlayer event data
					 */
					loadeddata: function(event){ // calls after setting the song duration
						// Don't process this for the main stream player
						if ($control[0].id !== liveStreamPlayer) {
							var songDuration = event.jPlayer.status.duration;

							var div = $control[0].id;
							var id = div.split('-')[2];


							var time = calcTime(songDuration);


							// Set it in the HTML
							document.getElementById('duration-' + id).innerHTML = time;

						}


					},
					play: function() {
						$control.addClass(cls);

						var songArtist = 'unknown';
						if (attrs.artist.length > 0) {
							songArtist = attrs.artist;
						}

						var songTitle = 'unknown';
						if (attrs.title.length > 0) {
							songTitle = attrs.title;
						}

						var utag_data = {};

						// Structure utag_data based on whether it's a live stream
						// or on-demand play

						// On-Demand Play
						if ($control[0].id !== liveStreamPlayer) {
							utag_data = {
								media_event: 'media_play',
								media_action: 'play',
								media_name : songArtist + ' - ' + songTitle,
								media_type: 'ondemand',
								content_type: 'Audio'
							};

							utag.link(utag_data);

						// Live Stream
						} else {
							utag_data = {
								media_event: 'media_play',
								stream_start: 'yes',
								media_action: 'play',
								media_name : songArtist + ' - ' + songTitle,
								media_type: 'live',
								content_type: 'audio stream'
							};
							utag.link(utag_data);
						}

						// this variable is used to track whether or not the player is playing
						// main purpose is for sitecatalyst tracking
						$rootScope.isPlaying = true;

						// Set the current player in the rootScope so it can be accessed by controllers
						$rootScope.currentPlayer = $control[0].id;
						$rootScope.currentPlayerPos = $control[0].offsetTop;

						if (attrs.pauseothers === 'true') {
							$player.jPlayer('pauseOthers');
						}
					},

					/**
					 * Event handler for when jPlayer time elapsed changes
					 * Occurs every 250ms
					 * This functions purpose is to update time elapsed for inline player
					 * @param {Object} event - jPlayer event data
					 */
					timeupdate: function(event) {
						// Don't process this for the main stream player
						if ($control[0].id !== liveStreamPlayer) {
							var timeElapsed = Math.floor(event.jPlayer.status.currentTime);
							var time = calcTime(timeElapsed);

							var div = $control[0].id;
							var id = div.split('-')[2];

							// Set it in the HTML
							document.getElementById('time-elapsed-' + id).innerHTML = time + '&nbsp;/&nbsp;';

						}
					},

					pause: function() {
						var id = $control[0].id;

						//$rootScope.currentPlayer = null;
						if (document.getElementById('floating-player-icon')) {
							document.getElementById('floating-player-icon').style.display = 'none';
						}

						// Don't process this for the main stream player
						if (id === liveStreamPlayer) {

							/*
							*  This command forces the live stream to stop
							*  so when the user plays it again, it plays
							*  from the current live moment
							*/
							$player.jPlayer('clearMedia');
						}

						// this rootscope variable is used for calling sitecatalyst
						// when a song changes. dont want to track when player is not playing
						$rootScope.isPlaying = false;

						$control.removeClass(cls);
					},
					/*
					stop: function() {
						$control.removeClass(cls);
					},
					*/
					ended: function() {
						$control.removeClass(cls);
					},

					/**
					 * Error handler for jPlayer
					 * This functions purpose is to update the main live stream
					 * when it gets paused. It will set the stream again and
					 * begin the buffer to allow the user to be live.
					 * @param {Object} event - jPlayer event data
					 */
					error: function(event) {
						if(event.jPlayer.error.type === 'e_url_not_set') {
							// Setup the media stream again and play it.
							$player
								.jPlayer('setMedia', {mp3: scope.$eval(attrs.audio)})
								.jPlayer('play');
						}
					}
				})
					.end()
					.unbind('click').click(function(e) {
						$player.jPlayer($control.hasClass(cls) ? 'pause' : 'play');
					});
			};

			scope.$watch(attrs.audio, updatePlayer);
			updatePlayer();

		}
	};
});

// Directive for handling titles (whether it scrolls or static text)
angular.module('mean.dandalin').directive('scrollText', function ($compile) {

	var getTemplate = function(contentType) {
		var template = '';
		var browserWidth = document.body.offsetWidth;

		var scrollText = '<marquee width="65%" scrollamount="2" behavior="scroll" direction="left" id="scroll-title">' + contentType + '</marquee>';
		var staticText = '<span>' + contentType + '</span>';

		if(contentType.length > 25 && browserWidth < 480) {
			template = scrollText;
		} else {
			template = staticText;
		}
		return template;
	};
	var linker = function(scope, element, attrs) {
		attrs.$observe('value', function (newValue) {
			element.html(getTemplate(newValue)).show();
			$compile(element.contents())(scope);
		});

	};
	return {
		restrict: 'E',
		replace: true,
		link: linker,
		scope: {
			content:'='
		}
	};
});

// Directive for the article description
angular.module('mean.dandalin').directive('description', function ($compile) {

	var getTemplate = function(description, url) {
		var template = '';

		// Grab the first paragraph of the description
		var shortDescription = description.split('</p>')[0];


		var longText = '<p>' + shortDescription + '    <a href="'+url+'" class="readMore">Karin Bayani</a></p>';
		var shortText = '<span>' + description + '</span>';

		// If the description is longer than 200 characters, only show first paragraph
		if(description.length > 200) {
			template = longText;
		// Otherwise show the whole thing
		} else {
			template = shortText;
		}
		return template;
	};
	var linker = function(scope, element, attrs) {
	//	attrs.$observe('value', function (newValue) {
			element.html(getTemplate(attrs.value, attrs.url)).show();
			$compile(element.contents())(scope);
	//	});

	};
	return {
		restrict: 'E',
		replace: true,
		link: linker,
		scope: {
			content:'='
		}
	};
});

// Directive to handle scroll position for the inline-players
angular.module('mean.dandalin').directive('scrollPosition', function($window, $rootScope) {
	return {
		scope: {
			scroll: '=scrollPosition'
		},
		link: function(scope, element, attrs) {
			var windowEl = angular.element($window);
			var liveStreamPlayer = 'jplayer-control';

			var togglePlayerIcon = function (attr) {

				if (attr === 'show') {
					$('#floating-player-icon').show();
				} else {
					$('#floating-player-icon').hide();
				}

			};

			var handler = function() {
				scope.scroll = windowEl.scrollTop();

				// If the player is playing
				if ($rootScope.currentPlayer && $rootScope.currentPlayer !== liveStreamPlayer) {
					// If the current scroll position is greater than the current player position
					// (When user scrolls DOWN past player)
					if (scope.scroll > $rootScope.currentPlayerPos) {

						// Show the floating player indicator icon
						togglePlayerIcon('show');

					// If the current scroll position is less than the current player position
					// (When user scrolls UP past player)
					} else if ((scope.scroll + 600) < $rootScope.currentPlayerPos) {

						// Show the floating player indicator icon
						togglePlayerIcon('show');

					// This condition is here for when the user is around the player (player is visible)
					} else {

						// Hide the floating player indicator icon
						togglePlayerIcon('hide');
					}

				}
			};
			windowEl.on('scroll', scope.$apply.bind(scope, handler));
			handler();

			// Unbind scroll event when user leaves page
			scope.$on('$destroy', function() {
				angular.element($window).unbind('scroll');
			});

		}
	};
});

// Directive for back button
angular.module('mean.dandalin').directive('backButton', function(){
	return {
		restrict: 'A',

		link: function(scope, element, attrs) {
			element.bind('click', goBack);

			function goBack() {
				history.back();
				scope.$apply();
			}
		}
	};
});

// Directive for Facebook Share
angular.module('mean.dandalin').directive('fbShare', [
	function() {
		return {
			restrict: 'A',
			link: function(scope, element) {
				element.on('click', function() {
					var link = '';
					var name = '';
					var picture = '';
					var description = '  ';

					// If it's a news article
					if (scope.news) {
						link = scope.news.shareURL;
						name = scope.news.title;

						// if picture exists
						if (scope.news.image) {
							picture = scope.news.image;
						}

						// have to use this replace function to strip HTML tags
						description = scope.news.description.replace(/<(?:.|\n)*?>/gm, '');

					// Else it's an on-demand song
					} else {
						link = scope.song.shareURL;
						name = scope.song.artist + ' - ' + scope.song.title;
						picture = 'http://beta.dandalinvoa.com/dandalin/assets/img/dandalin-icon.png';
					}


					FB.ui({
						method: 'feed',
						name: name,
						link: link,
						picture: picture,
						caption: ' ',
						description: description,
						message: ' '
					});


				});
			}
		};
	}
]);

/*
// Directive for handling promos
angular.module('mean.dandalin').directive('promo', function ($compile) {

	var getTemplate = function(obj) {
		var template = '';
		var promo = JSON.parse(obj);
		var targetEqualsBlank = '';
	//	var promoInlineStyles = 'font-family: Oswald; line-height: 1.5; margin-top: -9px; text-align: left; margin-left: -12px';

		// Checks to see if the URL provided is the same as the hostname
		// if it isn't, add target="_blank" so url opens in new tab
		if (promo.items[0].link.indexOf(window.location.hostname) < 0) {

			targetEqualsBlank = 'target="_blank"';
		}

		// Only the first element (promo.items[0]) is used here because it's the full width promo
		// The JSON always comes with 4 elements (2 for top promo space, 2 for bottom), the second
		// element is ignored if the fullWidth is true
		var fullWidth = '<div class="row">' +
							'<a ' + targetEqualsBlank + 'href="'+ promo.items[0].link+'" class="col-xs-3 tile-1x" style="background-image: url(' + promo.items[0].image + ');">' +
								'<div class="int-promo"><p>' + promo.items[0].text + '</p></div>' +
							'</a>' +
						'</div>';
		var halfWidth = '<div class="row">' +
							'<a ' + targetEqualsBlank + 'href="'+ promo.items[0].link+'" class="col-xs-3 tile-1x style="background-image: url(' + promo.items[0].image + ');">' +
								'<div class="int-promo"><p>' + promo.items[0].text + '</p></div>' +
							'</a>' +
							'<a ' + targetEqualsBlank + 'href="'+ promo.items[1].link+'" class="col-xs-3 tile-1x" style="background-image: url(' + promo.items[1].image + ');">' +
								'<div class="ext-promo"><p>' + promo.items[1].text + '</p></div>' +
							'</a>' +
						'</div>';


		if (promo.isFullWidth === 'true') {
			template = fullWidth;
		} else {
			template = halfWidth;
		}


		return template;
	};
	var linker = function(scope, element, attrs) {
		attrs.$observe('value', function (newValue) {
			element.html(getTemplate(newValue)).show();
			$compile(element.contents())(scope);
		});

	};
	return {
		restrict: 'E',
		replace: true,
		link: linker,
		scope: {
			content:'='
		}
	};
});
*/


// Directive for handling promos
angular.module('mean.dandalin').directive('promo', function ($compile) {

	var getTemplate = function(obj) {
		var template = '';
		var promo = JSON.parse(obj);
		var targetEqualsBlank = '';
		//	var promoInlineStyles = 'font-family: Oswald; line-height: 1.5; margin-top: -9px; text-align: left; margin-left: -12px';

		// Checks to see if the URL provided is the same as the hostname
		// if it isn't, add target="_blank" so url opens in new tab
		if (promo.items[0].link.indexOf(window.location.hostname) < 0) {

			targetEqualsBlank = 'target="_blank"';
		}

		// Only the first element (promo.items[0]) is used here because it's the full width promo
		// The JSON always comes with 4 elements (2 for top promo space, 2 for bottom), the second
		// element is ignored if the fullWidth is true
		var fullWidth = '<div class="rectangleInset gray" style="background-image: url(' + promo.items[0].image + ');">' +
							'<a ' + targetEqualsBlank + ' href="'+ promo.items[0].link +'">' +
								'<img src="/dandalin/assets/img/rectangle_transparent.png"/>' +
								'<div class="promo-text">' +
									'<h3>' + promo.items[0].text + '</h3>' +
								'</div>' +
							'</a>' +
						'</div>';
		var halfWidth = '<div class="squareInset left" style="background-image: url(' + promo.items[0].image + ');">' +
							'<a ' + targetEqualsBlank + ' href="' + promo.items[0].link + '">' +
								'<img src="/dandalin/assets/img/square_transparent.png"/>'+
								'<div class="promo-text">' +
									'<h3>' + promo.items[0].text + '</h3>' +
								'</div>' +
							'</a>' +
						'</div>' +
						'<div class="squareInset right" style="background-image: url(' + promo.items[1].image + ');"> ' +
							'<a ' + targetEqualsBlank + ' href="' + promo.items[1].link + '"> ' +
								'<img src="/dandalin/assets/img/square_transparent.png"/>' +
								'<div class="promo-text">' +
									'<h3>' + promo.items[1].text + '</h3>' +
								'</div>' +
							'</a>' +
						'</div>';
 

		if (promo.isFullWidth === 'true') {
			template = fullWidth;
		} else {
			template = halfWidth;
		}


		return template;
	};
	var linker = function(scope, element, attrs) {
		attrs.$observe('value', function (newValue) {
			element.html(getTemplate(newValue)).show();
			$compile(element.contents())(scope);
		});

	};
	return {
		restrict: 'E',
		replace: true,
		link: linker,
		scope: {
			content:'='
		}
	};
});

// directive for infinite scroll (used on news list pages)
angular.module('mean.dandalin').directive('whenScrolled', function() {
	return function(scope, elm, attr) {
		var raw = elm[0];

		elm.bind('scroll', function() {
			if (raw.scrollTop + raw.offsetHeight >= raw.scrollHeight) {
				scope.$apply(attr.whenScrolled);
			}
		});
	};
});


