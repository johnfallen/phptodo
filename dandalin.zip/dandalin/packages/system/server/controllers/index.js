'use strict';

var mean = require('meanio');
var config = mean.config.clean;
var dandalinApplication = require('../../../dandalin/server/service/DandalinApplication');

exports.render = function(req, res) {

  var modules = [];
  // Preparing angular modules list with dependencies
  for (var name in mean.modules) {
    modules.push({
      name: name,
      module: 'mean.' + name,
      angularDependencies: mean.modules[name].angularDependencies
    });
  }

  function isAdmin() {
    return req.user && req.user.roles.indexOf('admin') !== -1;
  }


  // Send some basic starting info to the view
  res.render('index', {
    user: req.user ? {
      name: req.user.name,
      _id: req.user._id,
      username: req.user.username,
      roles: req.user.roles
    } : {},
    modules: modules,
    isAdmin: isAdmin,
    fayeClientJS : config.faye.url + '/client.js',
    tealiumClientJS : config.tealiumConfig.scriptName,
    tealiumTagData : JSON.stringify(config.tealiumConfig.tagData),
    dandalinConfig : JSON.stringify(getFrontEndConfigObject()),
    adminEnabled: isAdmin() && mean.moduleEnabled('mean-admin'),
    env : process.env.NODE_ENV,
    FACEBOOK_APP_ID : config.metaTagData.FACEBOOK_APP_ID,
    APP_URL : config.metaTagData.APP_URL,
    APP_LOGO : config.metaTagData.APP_LOGO
  });
};


/**
 * I return the config object to put in the head for the front end application.
 * @returns {Object} - I am the config object.
 */
function getFrontEndConfigObject(){

  var configJSON = {};
  configJSON.faye = {};
  configJSON.tealiumConfig = {};

  configJSON.JSONDataPath = config.relativeJSONDirectory;
  configJSON.faye.url = config.faye.url;
  configJSON.faye.radioChannel = config.faye.radioChannel;
  configJSON.faye.newsChannel = config.faye.newsChannel;
  configJSON.faye.breakingNewsChannel = config.faye.breakingNewsChannel;
  configJSON.faceBookAppID = config.faceBookAppID;
  configJSON.itemCodeFlag = config.playerItemCodeFlagArray;
  configJSON.soccerIFrameURL = config.soccerIFrameURL;
  configJSON.tealiumConfig.scriptName = config.tealiumConfig.scriptName;
	configJSON.newsState = dandalinApplication.getNewsState();

  for ( var key in configJSON.itemCodeFlag ){

    delete configJSON.itemCodeFlag[key].artistName;
    delete configJSON.itemCodeFlag[key].titleName;
    delete configJSON.itemCodeFlag[key].albumName;
  }

  return configJSON;
}
