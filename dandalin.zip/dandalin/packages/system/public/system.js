'use strict';

angular.module('mean.system', ['mean-factory-interceptor']);
